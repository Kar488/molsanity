# Optimiser levers — design mock

Two candidate designs for the screen that answers **“what did the optimiser pull,
and where did it land?”** It hangs off the existing Sales bridge (the waterfall)
as a second tab: *the bridge* answers **how much**, *the levers* answers **what**
and **where**.

## How to open it

Double-click `optimiser-levers-explainer.html`. No build, no server, no install.

It is a **single self-contained file** — all CSS and JS are inline. The only
external reference is the Google Fonts stylesheet for Inter; with no internet it
falls back to the system sans and everything still works and still lays out
correctly.

## What is on the screen

**Left rail — INPUT.** The three levers the optimiser moved, week by week vs LY:
promo rate (how many items), promo depth (how hard), in circular (how much ad
weight). Solid line = this plan, dashed = last year. Deliberately recessive: the
outcome panel on the right is what the reader is here for.

**Right panel — OUTCOME.** Two alternatives, both showing Sales / Units / AGP
side by side rather than behind a toggle, because the cross-objective comparison
is the point (an item down on sales but flat on units is a price effect, not lost
demand — you only see that by reading the same row across three panels).

- **Option A — three waffle grids (recommended).** One square per item; row
  length is the item count, square colour is that item’s variance vs LY. Squares
  are sorted worst → best within each row, so how far the red runs *is* the read.
- **Option B — three beeswarms.** One dot per item; y is % variance, dot area is
  the value at stake. This is the view that names individual items.

## Controls (in the mock, to stress the designs)

| Control | Purpose |
|---|---|
| **Horizon** — 14 wks / 65 wks | Drives the lever rail. Proves the sparklines work at both densities. |
| **Assortment** — 30 / 400 NCRCs | The two ends of what a category runs. Both designs adapt. |
| **Dot area** (Option B) — value at stake / LY size | See “Two encodings” below. |
| **Theme** — light / dark | Both are designed, not auto-flipped. |
| **Texture** — off / on | Colourblind / print / forced-colors channel. |

The right-hand totals stay pinned to the 14-week bridge figure (−$161.1K sales,
−37.5K units, −$52.8K AGP) at every setting, so they remain checkable against the
waterfall. Only the lever rail responds to the horizon control.

## The problem this screen solves

> “$ alone hides how big the miss is; % alone makes 1→5 look like a 500 % error.”

Both options carry **count and value together**, so a percentage is never read
without knowing what it is worth. That constraint drove most of what follows.

## Design rules a developer needs to preserve

These are the parts where the obvious implementation is wrong.

**Item roles are a pyramid.** Critical is a handful of lines carrying most of the
money, widening through KVI to a long Background tail — roughly 3 / 8 / 14 / 30 /
45 % of the count. Both assortment sizes hold that shape.

**Variance bands are per role.** ±3 % Critical, ±5 % SSKVI, ±8 % KVI, ±15 %
Foreground, ±25 % Background. The same percentage is a breach at the top of the
pyramid and noise at the bottom. Drawn as the shaded capsule behind each beeswarm
column.

**In-circular is a separate attribute.** ~8 % of the assortment, allocated as a
quota per role then top-value within each (a circular is built deliberately, not
by a coin flip). It is the **ring** on a beeswarm dot. Out-of-band is stated in
words in the tooltip instead — the two never share a visual channel.

**Option B’s y-axis: linear to ±25 %, compressed beyond, capped at ±400 %.**
Items past the cap sit in an **overflow rail** outside the plot with a count, not
clipped and not stretching the scale. One +620 % item on a $400 base would
otherwise squash every real reading into a few pixels.

**Never a dual axis.** An earlier draft put item count on the left y and variance
colour on a right y. A second y-scale invents a correlation that is not in the
data. Option A’s colour scale replaces it.

**Adaptive geometry, not fixed caps.**
- Waffle squares size to hold the longest row to ~7 wrapped lines.
- Beeswarm dot radius derives from the plot area available *per item*, floored at
  2.4 px. A fixed ceiling left a 30-item category as specks in an empty panel.
- The hovered beeswarm dot is redrawn at 7 px — a 2.4 px dot cannot show a hover
  state at its own size.

**Beeswarm packing** is the real algorithm: candidate offsets are the tangent
points against live neighbours (windowed by y), taking the position nearest the
centre line that clears everything. Verified at zero overlaps for 1,200 dots.

**Hit targets.** Waffle squares and beeswarm dots both use a nearest-point layer —
the pointer only has to be *closest*, never dead-centre.

## Two encodings for dot area (Option B)

- **LY size** = how big the item is. Answers *“which of my big items got touched?”*
- **Value at stake** = |Δ$|, how much money it lost or gained. Answers *“where did
  the gap come from?”*

Both are true and they disagree: an item that sold $6.2K last year and landed at
+0.2 % (so moved $10) is a fat dot under one and nearly invisible under the other.
Value at stake is the default because this screen exists to explain the gap.
**This is an open design decision** — if merchants’ first question is “did the
optimiser touch my important lines?”, LY size is the better default.

## Colour

The palette is validated, not eyeballed. Diverging blue ↔ red, checked for
lightness band, chroma floor, colourblind separation and surface contrast in
**both** light and dark. Worst adjacent CVD ΔE 17.5 light / 15.5 dark.

Two deliberate departures, both worth keeping:

1. **The lever line is not the diverging pole.** A pole must hold a chroma floor
   and CVD separation against the red arm; the lever chart has one series and a
   dashed neutral reference, where identity comes from solid-vs-dashed, not hue.
   So it can be a quiet slate (`--s1`) that a pole never could.
2. **The waffle runs a paler arm of the same hues** (`--wf-*`). Its near-zero
   steps sit at ~1.5:1 against the panel, below the 2:1 ordinal floor — on
   purpose, because this is a diverging *magnitude* scale and “almost nothing
   happened here” should recede. Every square carries a hairline edge so a pale
   one is still countable, and no value is colour-only (row labels state counts,
   hover names the item).

All colour lives in CSS custom properties at the top of the file — one `html[data-theme="light"]`
block and one `html[data-theme="dark"]`. Swap those for the real design tokens and
nothing else needs to change.

## What is mock and what is real

**Mock:** all item-level data is generated in-file from a seeded RNG (`buildData`),
so it is deterministic — the same numbers every time you open it. The generator
models an optimiser as a three-component mixture (promo pulled / flat /
promoted-with-ad) because an optimiser *trades*; it does not shift everything
uniformly, and a single normal distribution produced a chart not worth reading.

**Real:** the headline figures tie to the Sales bridge for Facial Tissue ·
Denver — LY $830.1K, plan $669.0K, −19.4 %.

## Where it hangs off the bridge

The three optimiser bars in the waterfall — *promoted no ad*, *promoted with ad*,
*non-promoted* — become clickable and deep-link into this screen with the grid
pre-filtered to that decision group. That is the natural “show me why” path from
the number the user is already staring at.

---

Every non-obvious decision is commented inline in the file, including the ones
that were tried and rejected — worth reading those before changing the geometry.
