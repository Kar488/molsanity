"""MI forecast-bridge waterfall (merchant explainability).

Decomposes a selected optimizer plan's FY forecast versus calendar-mapped LY actuals into
additive bridge components at item x price-area x week grain, computed separately for
sales, units, and agp:

  Q4-LY actual
  + underlying category trend             (metric-specific frozen-period YoY growth applied to LY)
  + trend momentum                        (post-freeze weekly path projected from the freeze-week actual)
  + mechanical regular-price effect       (LY units x YoY regular-price change; 0 for units)
  + frozen cost & allowance effect        (AGP only: LY units x deadnet-cost change)
  + optimizer promotion effect            (selected promo slots vs the same slot's no-promo
                                           candidate forecast, grouped by any TY slot incidence:
                                           promoted-no-ad / promoted-with-ad / non-promoted)
  + residual                              (closes the bridge by construction)
  = FY forecast

Pure pandas plus SQL string builders, so the Databricks notebook (spark.sql) and the FastAPI
service (databricks-sql-connector) share one implementation.
"""
from __future__ import annotations

from typing import Any

import pandas as pd

METRICS = ("sales", "units", "agp")

# Fixed enterprise sources for LY sales excluded from optimizer scope. These are infrastructure
# tables, not request-level choices; callers only provide the division/category/run filters.
ITEM_HIERARCHY_TABLE = "line8.alberstons_agentic_build_prod_testing.item_hierarchy"
PROMO_CALENDAR_TABLE = "line8.alberstons_agentic_build_prod_testing.promo_calendar"
SALES_COST_ALLOWANCES_TABLE = (
    "line8.alberstons_agentic_build_prod_testing.sales_cost_allowances"
)

# metric -> (selected-plan FY column, selected-plan LY column, baseline no-promo column)
_METRIC_COLS = {
    "sales": ("optimizer_revenue", "ly_sales", "base_sales"),
    "units": ("optimizer_units", "ly_units", "base_units"),
    "agp": ("optimizer_agp", "ly_agp", "base_agp"),
}

_OBJECTIVE_ALIASES = {
    "sales": "REVENUE",
    "revenue": "REVENUE",
    "units": "UNITS",
    "agp": "AGP",
}

# The merchant story in four numbers: which waterfall step rolls into which contributor.
_CONTRIBUTOR_BUCKETS = {
    "category_trend": "organic_demand",
    "trend_momentum": "organic_demand",
    "store_footprint": "organic_demand",
    "mechanical_price": "pricing_and_cost",
    "frozen_price_gap": "pricing_and_cost",
    "frozen_cost": "pricing_and_cost",
    "frozen_cost_gap": "pricing_and_cost",
    "optimizer_promoted_no_ad": "optimization",
    "optimizer_promoted_with_ad": "optimization",
    "optimizer_nonpromoted": "optimization",
    "residual": "model_variance",
}
CONTRIBUTOR_ORDER = ("organic_demand", "pricing_and_cost", "optimization", "model_variance")

SLOT_KEYS = ["item_id", "price_area_cd", "week_start_date"]

# CRF promotion-depth columns. The digital column is spelled differently across CRF builds, so
# every query that reads it takes the name as a parameter and ``run_waterfall`` resolves the one
# the table actually carries. Hardcoding it in one query and defaulting to the other spelling
# elsewhere silently disables whichever query guessed wrong.
STORE_DEPTH_COLS = ("CMS_store_promo_depth", "OMS_store_promo_depth")
DEFAULT_DIGITAL_DEPTH_COL = "OMS_digital_promo_depth"
DIGITAL_DEPTH_COL_CANDIDATES = ("OMS_digital_promo_depth", "digital_promo_depth")


def resolve_digital_depth_col(table_cols: set[str] | None) -> str | None:
    """Which digital promo-depth spelling this CRF table carries, or None when it carries neither.

    ``table_cols`` is the lowercase column probe; None (probe failed) yields the default so the
    queries stay runnable.
    """
    if table_cols is None:
        return DEFAULT_DIGITAL_DEPTH_COL
    for candidate in DIGITAL_DEPTH_COL_CANDIDATES:
        if candidate.lower() in table_cols:
            return candidate
    return None


def normalize_objective(objective: str) -> str:
    """Map a user-facing objective (sales/revenue/units/agp) to the plan objective label."""
    key = str(objective or "").strip().lower()
    if key not in _OBJECTIVE_ALIASES:
        raise ValueError(f"objective must be one of {sorted(_OBJECTIVE_ALIASES)}; got {objective!r}")
    return _OBJECTIVE_ALIASES[key]


# ---------------------------------------------------------------------------
# SQL builders (plain strings so spark.sql and databricks-sql share them)
# ---------------------------------------------------------------------------

def _lit(value: Any) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _scope_predicates(
    *,
    category: str | None = None,
    category_id: str | None = None,
    division_id: str | None = None,
    item_id: str | None = None,
    price_area_cd: str | None = None,
    item_col: str = "item_id",
    price_area_col: str = "price_area_cd",
    has_category_id: bool = True,
    has_division_id: bool = True,
) -> list[str]:
    preds: list[str] = []
    if category:
        preds.append(f"UPPER(TRIM(category)) = {_lit(str(category).strip().upper())}")
    if category_id and has_category_id:
        preds.append(f"CAST(category_id AS STRING) = {_lit(str(category_id).strip())}")
    if division_id and has_division_id:
        preds.append(f"CAST(division_id AS STRING) = {_lit(str(division_id).strip())}")
    if item_id:
        preds.append(f"CAST({item_col} AS STRING) = {_lit(str(item_id).strip())}")
    if price_area_cd:
        preds.append(f"CAST({price_area_col} AS STRING) = {_lit(str(price_area_cd).strip())}")
    return preds


def build_selected_plan_sql(
    detail_table: str,
    *,
    run_id: str,
    objective: str,
    plan_rank: int = 1,
    category: str | None = None,
    category_id: str | None = None,
    division_id: str | None = None,
    item_id: str | None = None,
    price_area_cd: str | None = None,
    week_start: str | None = None,
    week_end: str | None = None,
    has_category_id: bool = True,
    has_division_id: bool = True,
) -> str:
    """Selected-plan slots (one row per item x price-area x week) for one objective plan."""
    obj = normalize_objective(objective)
    preds = [
        f"run_id = {_lit(run_id)}",
        "is_optimizer_selected = true",
        f"optimizer_rank = {int(plan_rank)}",
        f"UPPER(TRIM(optimizer_objective)) = {_lit(obj)}",
        "UPPER(TRIM(report_objective)) = UPPER(TRIM(optimizer_objective))",
    ]
    preds += _scope_predicates(
        category=category, category_id=category_id, division_id=division_id,
        item_id=item_id, price_area_cd=price_area_cd,
        has_category_id=has_category_id, has_division_id=has_division_id,
    )
    if week_start:
        preds.append(f"week_start_date >= {_lit(week_start)}")
    if week_end:
        preds.append(f"week_start_date <= {_lit(week_end)}")
    where = "\n  AND ".join(preds)
    return f"""
SELECT
  CAST(item_id AS STRING)        AS item_id,
  CAST(price_area_cd AS STRING)  AS price_area_cd,
  CAST(week_start_date AS STRING) AS week_start_date,
  item_name,
  category,
  COALESCE(in_circular, 0)              AS in_circular,
  COALESCE(store_depth, 0.0)            AS store_depth,
  COALESCE(digital_depth, 0.0)          AS digital_depth,
  COALESCE(ly_store_promo_depth, 0.0)   AS ly_store_promo_depth,
  COALESCE(ly_digital_promo_depth, 0.0) AS ly_digital_promo_depth,
  optimizer_units,
  optimizer_revenue,
  optimizer_agp,
  ly_units,
  ly_sales,
  ly_agp
FROM {detail_table}
WHERE {where}
""".strip()


def build_baseline_sql(
    detail_table: str,
    *,
    run_id: str,
    category: str | None = None,
    category_id: str | None = None,
    division_id: str | None = None,
    item_id: str | None = None,
    price_area_cd: str | None = None,
    week_start: str | None = None,
    week_end: str | None = None,
    has_category_id: bool = True,
    has_division_id: bool = True,
) -> str:
    """Per-slot no-promo candidate forecast (raw CRF display columns), objective-independent."""
    preds = [
        f"run_id = {_lit(run_id)}",
        "COALESCE(store_depth, 0.0) = 0.0",
        "COALESCE(digital_depth, 0.0) = 0.0",
    ]
    preds += _scope_predicates(
        category=category, category_id=category_id, division_id=division_id,
        item_id=item_id, price_area_cd=price_area_cd,
        has_category_id=has_category_id, has_division_id=has_division_id,
    )
    if week_start:
        preds.append(f"week_start_date >= {_lit(week_start)}")
    if week_end:
        preds.append(f"week_start_date <= {_lit(week_end)}")
    where = "\n  AND ".join(preds)
    return f"""
SELECT
  CAST(item_id AS STRING)         AS item_id,
  CAST(price_area_cd AS STRING)   AS price_area_cd,
  CAST(week_start_date AS STRING) AS week_start_date,
  AVG(units)   AS base_units,
  AVG(revenue) AS base_sales,
  AVG(agp)     AS base_agp
FROM {detail_table}
WHERE {where}
GROUP BY 1, 2, 3
""".strip()


def build_ly_circular_sql(
    crf_table: str,
    detail_table: str | None = None,
    *,
    run_id: str,
    week_start: str | None = None,
    week_end: str | None = None,
    objective: str = "sales",
    plan_rank: int = 1,
    division_id: str | None = None,
    category: str | None = None,
    category_id: str | None = None,
    item_id: str | None = None,
    price_area_cd: str | None = None,
    has_category_id: bool = True,
    detail_has_category_id: bool = True,
    detail_has_division_id: bool = True,
    circular_col: str = "in_circular",
    digital_depth_col: str = DEFAULT_DIGITAL_DEPTH_COL,
) -> str:
    """Q4-LY promotion and advertising at item x price-area x aligned-future-week grain.

    The selected future bounds are shifted back 364 days. Store rows are collapsed only within
    the same item, price area, and week. Both promotion and advertising are derived from CRF;
    the LY week is shifted forward 364 days so it joins the corresponding selected-plan slot.
    """
    crf_scope = _scope_predicates(
        category=category, category_id=category_id, item_id=item_id,
        price_area_cd=price_area_cd, item_col="national_common_retail_cd",
        price_area_col="price_area_cd", has_category_id=has_category_id,
        has_division_id=False,
    )
    crf_scope_sql = ("\n  AND " + "\n  AND ".join(crf_scope)) if crf_scope else ""

    if week_start and week_end:
        bounds_sql = f"""
SELECT
  DATE {_lit(week_start)} AS future_start_week,
  DATE {_lit(week_end)} AS future_end_week
""".strip()
    else:
        if not detail_table:
            raise ValueError(
                "detail_table is required when week_start or week_end is not provided"
            )
        obj = normalize_objective(objective)
        detail_preds = [
            f"run_id = {_lit(run_id)}",
            "is_optimizer_selected = true",
            f"optimizer_rank = {int(plan_rank)}",
            f"UPPER(TRIM(optimizer_objective)) = {_lit(obj)}",
            "UPPER(TRIM(report_objective)) = UPPER(TRIM(optimizer_objective))",
        ]
        detail_preds += _scope_predicates(
            category=category, category_id=category_id, division_id=division_id,
            item_id=item_id, price_area_cd=price_area_cd,
            has_category_id=detail_has_category_id,
            has_division_id=detail_has_division_id,
        )
        if week_start:
            detail_preds.append(f"week_start_date >= {_lit(week_start)}")
        if week_end:
            detail_preds.append(f"week_start_date <= {_lit(week_end)}")
        detail_where = "\n    AND ".join(detail_preds)
        start_expr = f"DATE {_lit(week_start)}" if week_start else "MIN(CAST(week_start_date AS DATE))"
        end_expr = f"DATE {_lit(week_end)}" if week_end else "MAX(CAST(week_start_date AS DATE))"
        bounds_sql = f"""
SELECT
  {start_expr} AS future_start_week,
  {end_expr} AS future_end_week
FROM {detail_table}
WHERE {detail_where}
""".strip()

    depth_expr = "GREATEST(\n    " + ",\n    ".join(
        f"COALESCE({col}, 0.0)" for col in (*STORE_DEPTH_COLS, digital_depth_col)
    ) + "\n  )"

    return f"""
WITH plan_bounds AS (
{bounds_sql}
)
SELECT
  CAST(national_common_retail_cd AS STRING) AS item_id,
  CAST(price_area_cd AS STRING) AS price_area_cd,
  CAST(DATE_ADD(week_start_dt, 364) AS STRING) AS week_start_date,
  MAX({depth_expr}) AS ly_promo_depth,
  MAX(CASE WHEN {depth_expr} > 1e-9 THEN 1 ELSE 0 END) AS promoted_ly,
  MAX(CASE WHEN {depth_expr} > 1e-9
    AND COALESCE({circular_col}, 0) <> 0
    THEN 1 ELSE 0 END) AS advertised_ly
FROM {crf_table}
 CROSS JOIN plan_bounds b
WHERE run_id = {_lit(run_id)}
  AND future_data_flag = 'N'
  AND week_start_dt BETWEEN DATE_SUB(b.future_start_week, 364)
                        AND DATE_SUB(b.future_end_week, 364){crf_scope_sql}
GROUP BY 1, 2, 3
""".strip()


def build_store_count_effect_sql(
    store_detail_table: str,
    candidate_detail_table: str,
    *,
    run_id: str,
    objective: str,
    week_start: str,
    week_end: str,
    plan_rank: int = 1,
    division_id: str | None = None,
    category: str | None = None,
    category_id: str | None = None,
    item_id: str | None = None,
    price_area_cd: str | None = None,
    has_category_id: bool = True,
    has_division_id: bool = True,
    store_has_category_id: bool = True,
    store_has_future_data_flag: bool = False,
    store_item_col: str = "item_id",
    store_price_area_col: str = "price_area_cd",
    store_id_col: str = "facility_integration_id",
    store_week_col: str = "week_start_dt",
    store_active_col: str = "units",
    store_future_data_flag_col: str = "future_data_flag",
) -> str:
    """Period-level store-footprint effects at item x price-area grain.

    A store belongs to a period when it records positive ``store_active_col`` at least once. The
    selected plan determines the comparable-LY Q4 bounds. Distinct LY-Q4 stores are compared with
    distinct stores observed over the SAME NUMBER OF WEEKS ending at the last actual (freeze)
    week. The current footprint is assumed to remain available in the future Q4, holding each
    item's LY performance per store flat across the full selected horizon.

    The two windows must be equal length. Count-distinct under an at-least-once rule rises
    monotonically with window length, so comparing a 13-week LY window against everything from
    the end of LY Q4 to the freeze week (25-35 weeks in a typical run) reports a footprint gain
    that is an artefact of the longer window. ``ly_window_weeks`` and ``current_window_weeks``
    are returned so the comparison can be verified rather than assumed.
    """
    obj = normalize_objective(objective)
    selected_preds = [
        f"run_id = {_lit(run_id)}",
        "is_optimizer_selected = true",
        f"optimizer_rank = {int(plan_rank)}",
        f"UPPER(TRIM(optimizer_objective)) = {_lit(obj)}",
        "UPPER(TRIM(report_objective)) = UPPER(TRIM(optimizer_objective))",
    ]
    selected_preds += _scope_predicates(
        category=category, category_id=category_id, division_id=division_id,
        item_id=item_id, price_area_cd=price_area_cd,
        has_category_id=has_category_id, has_division_id=has_division_id,
    )
    if week_start:
        selected_preds.append(f"week_start_date >= {_lit(week_start)}")
    if week_end:
        selected_preds.append(f"week_start_date <= {_lit(week_end)}")
    selected_where = "\n    AND ".join(selected_preds)

    store_preds = [
        f"run_id = {_lit(run_id)}",
    ]
    store_preds += _scope_predicates(
        category=category, category_id=category_id,
        item_id=item_id, price_area_cd=price_area_cd,
        item_col=store_item_col, price_area_col=store_price_area_col,
        has_category_id=store_has_category_id, has_division_id=False,
    )
    store_where = "\n    AND ".join(store_preds)
    actual_only = (
        f"UPPER(TRIM(CAST({store_future_data_flag_col} AS STRING))) = 'N'"
        if store_has_future_data_flag
        else f"CAST({store_week_col} AS DATE) < p.future_start_week"
    )

    return f"""
WITH selected AS (
  SELECT
    CAST(item_id AS STRING)         AS item_id,
    CAST(price_area_cd AS STRING)   AS price_area_cd,
    MIN(CAST(week_start_date AS DATE)) AS item_future_start_week,
    MAX(CAST(week_start_date AS DATE)) AS item_future_end_week,
    SUM(COALESCE(ly_sales, 0.0))       AS ly_sales,
    SUM(COALESCE(ly_units, 0.0))       AS ly_units,
    SUM(COALESCE(ly_agp, 0.0))         AS ly_agp
  FROM {candidate_detail_table}
  WHERE {selected_where}
  GROUP BY 1, 2
),
plan_bounds AS (
  SELECT
    MIN(item_future_start_week)                AS future_start_week,
    MAX(item_future_end_week)                  AS future_end_week,
    DATE_SUB(MIN(item_future_start_week), 364) AS ly_start_week,
    DATE_SUB(MAX(item_future_end_week), 364)   AS ly_end_week,
    DATEDIFF(MAX(item_future_end_week), MIN(item_future_start_week)) / 7 + 1
                                               AS plan_weeks
  FROM selected
),
store_actual_rows AS (
  SELECT
    CAST({store_item_col} AS STRING)       AS item_id,
    CAST({store_price_area_col} AS STRING) AS price_area_cd,
    CAST({store_id_col} AS STRING)         AS store_id,
    CAST({store_week_col} AS DATE)         AS week_start_date,
    COALESCE({store_active_col}, 0.0)      AS active_units
  FROM {store_detail_table}
  CROSS JOIN plan_bounds p
  WHERE {store_where}
    AND CAST({store_week_col} AS DATE) >= p.ly_start_week
    AND {actual_only}
),
actual_bounds AS (
  SELECT MAX(week_start_date) AS freeze_week
  FROM store_actual_rows
),
active_store_observations AS (
  SELECT item_id, price_area_cd, store_id, week_start_date
  FROM store_actual_rows
  WHERE active_units > 0.0
),
ly_store_counts AS (
  SELECT
    a.item_id,
    a.price_area_cd,
    COUNT(DISTINCT a.store_id) AS ly_store_count
  FROM active_store_observations a
  CROSS JOIN plan_bounds p
  WHERE a.week_start_date BETWEEN p.ly_start_week AND p.ly_end_week
  GROUP BY 1, 2
),
freeze_store_counts AS (
  -- Same number of weeks as the LY window, ending at the freeze week.
  SELECT
    a.item_id,
    a.price_area_cd,
    COUNT(DISTINCT a.store_id) AS freeze_store_count
  FROM active_store_observations a
  CROSS JOIN plan_bounds p
  CROSS JOIN actual_bounds f
  WHERE a.week_start_date > DATE_SUB(f.freeze_week, CAST(p.plan_weeks AS INT) * 7)
    AND a.week_start_date <= f.freeze_week
  GROUP BY 1, 2
)
SELECT
  s.item_id,
  s.price_area_cd,
  CAST(p.plan_weeks AS INT)                                   AS ly_window_weeks,
  CAST(p.plan_weeks AS INT)                                   AS current_window_weeks,
  COALESCE(f.freeze_store_count, 0)                           AS future_store_count,
  COALESCE(l.ly_store_count, 0)                               AS ly_store_count,
  COALESCE(f.freeze_store_count, 0) - COALESCE(l.ly_store_count, 0)
                                                               AS store_count_change,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_sales / l.ly_store_count END                 AS ly_sales_per_store,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_sales / l.ly_store_count
            * COALESCE(f.freeze_store_count, 0) END           AS expected_sales,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_sales / l.ly_store_count
            * COALESCE(f.freeze_store_count, 0) - s.ly_sales END
                                                               AS d_store_sales,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_units / l.ly_store_count END                 AS ly_units_per_store,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_units / l.ly_store_count
            * COALESCE(f.freeze_store_count, 0) END           AS expected_units,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_units / l.ly_store_count
            * COALESCE(f.freeze_store_count, 0) - s.ly_units END
                                                               AS d_store_units,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_agp / l.ly_store_count END                   AS ly_agp_per_store,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_agp / l.ly_store_count
            * COALESCE(f.freeze_store_count, 0) END           AS expected_agp,
  CASE WHEN l.ly_store_count > 0
       THEN s.ly_agp / l.ly_store_count
            * COALESCE(f.freeze_store_count, 0) - s.ly_agp END
                                                               AS d_store_agp
FROM selected s
CROSS JOIN plan_bounds p
LEFT JOIN ly_store_counts l
  ON s.item_id = l.item_id
 AND COALESCE(s.price_area_cd, '') = COALESCE(l.price_area_cd, '')
LEFT JOIN freeze_store_counts f
  ON s.item_id = f.item_id
 AND COALESCE(s.price_area_cd, '') = COALESCE(f.price_area_cd, '')
""".strip()


def build_price_match_sql(
    crf_table: str,
    *,
    run_id: str,
    week_start: str,
    week_end: str,
    category: str | None = None,
    category_id: str | None = None,
    item_id: str | None = None,
    price_area_cd: str | None = None,
    has_category_id: bool = True,
) -> str:
    """Matched item x store x week (future vs -364d history) price/cost deltas, aggregated to
    item x price-area x future-week. LY units weight the regular-price and deadnet-cost changes."""
    scope = _scope_predicates(
        category=category, category_id=category_id,
        item_id=item_id, price_area_cd=price_area_cd,
        item_col="national_common_retail_cd", price_area_col="price_area_cd",
        has_category_id=has_category_id, has_division_id=False,
    )
    scope_sql = ("\n    AND " + "\n    AND ".join(scope)) if scope else ""
    return f"""
WITH f AS (
  SELECT
    CAST(national_common_retail_cd AS STRING) AS item_id,
    CAST(price_area_cd AS STRING)     AS price_area_cd,
    CAST(facility_integration_id AS STRING)   AS facility_integration_id,
    week_start_dt,
    regular_price                             AS fut_regular_price,
    ncrc_per_unit_deadnet_cost_x_flat         AS fut_deadnet
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'Y'
    AND week_start_dt BETWEEN DATE {_lit(week_start)} AND DATE {_lit(week_end)}{scope_sql}
),
h AS (
  SELECT
    CAST(national_common_retail_cd AS STRING) AS item_id,
    CAST(price_area_cd AS STRING)     AS price_area_cd,
    CAST(facility_integration_id AS STRING)   AS facility_integration_id,
    week_start_dt,
    regular_price                             AS ly_regular_price,
    ncrc_per_unit_deadnet_cost_x_flat         AS ly_deadnet,
    units                                     AS ly_units
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'N'
    AND week_start_dt BETWEEN date_sub(DATE {_lit(week_start)}, 364) AND date_sub(DATE {_lit(week_end)}, 364){scope_sql}
)
SELECT
  f.item_id,
  f.price_area_cd,
  CAST(f.week_start_dt AS STRING)                              AS week_start_date,
  COUNT(*)                                                     AS matched_store_weeks,
  SUM(h.ly_units)                                              AS ly_units,
  SUM(h.ly_units * (f.fut_regular_price - h.ly_regular_price)) AS d_price_sales,
  SUM(h.ly_units * (h.ly_deadnet - f.fut_deadnet))             AS d_cost_agp,
  SUM(h.ly_units * f.fut_regular_price)                        AS ly_units_x_fut_price,
  SUM(h.ly_units * f.fut_deadnet)                              AS ly_units_x_fut_deadnet
FROM f
JOIN h
  ON f.item_id = h.item_id
 AND f.facility_integration_id = h.facility_integration_id
 AND COALESCE(f.price_area_cd, '') = COALESCE(h.price_area_cd, '')
 AND h.week_start_dt = date_sub(f.week_start_dt, 364)
GROUP BY 1, 2, 3
""".strip()


def build_price_drift_sql(
    crf_table: str,
    *,
    run_id: str,
    drift_weeks: int = 13,
    category: str | None = None,
    category_id: str | None = None,
    price_area_cd: str | None = None,
    has_category_id: bool = True,
) -> str:
    """Historical annual drift of regular price and dead-net cost, plus the freeze week.

    Matched item x store x week pairs over the most recent ``drift_weeks`` history weeks vs the
    same weeks 364 days (52 promo weeks) earlier, weighted by the PRIOR period's units on both
    sides so the ratio measures pure price movement, not mix shift. ``freeze_week`` is the last
    actual history week — the point the forecast's prices and costs were frozen at."""
    scope = _scope_predicates(
        category=category, category_id=category_id, price_area_cd=price_area_cd,
        price_area_col="price_area_cd",
        has_category_id=has_category_id, has_division_id=False,
    )
    scope_sql = ("\n    AND " + "\n    AND ".join(scope)) if scope else ""
    return f"""
WITH hist AS (
  SELECT
    CAST(national_common_retail_cd AS STRING) AS item_id,
    CAST(price_area_cd AS STRING)     AS price_area_cd,
    CAST(facility_integration_id AS STRING)   AS facility_integration_id,
    week_start_dt,
    units,
    regular_price,
    ncrc_per_unit_deadnet_cost_x_flat         AS deadnet
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'N'
    AND regular_price > 0{scope_sql}
),
maxw AS (SELECT MAX(week_start_dt) AS mx FROM hist),
cur AS (
  SELECT hist.* FROM hist CROSS JOIN maxw
  WHERE hist.week_start_dt > date_sub(maxw.mx, {int(drift_weeks)} * 7)
)
SELECT
  COUNT(*)                                                    AS matched_pairs,
  SUM(p.units * c.regular_price) / NULLIF(SUM(p.units), 0)    AS cur_wavg_price,
  SUM(p.units * p.regular_price) / NULLIF(SUM(p.units), 0)    AS prior_wavg_price,
  SUM(p.units * c.deadnet) / NULLIF(SUM(p.units), 0)          AS cur_wavg_deadnet,
  SUM(p.units * p.deadnet) / NULLIF(SUM(p.units), 0)          AS prior_wavg_deadnet,
  CAST((SELECT mx FROM maxw) AS STRING)                       AS freeze_week
FROM cur c
JOIN hist p
  ON c.item_id = p.item_id
 AND c.facility_integration_id = p.facility_integration_id
 AND COALESCE(c.price_area_cd, '') = COALESCE(p.price_area_cd, '')
 AND p.week_start_dt = date_sub(c.week_start_dt, 364)
 AND p.regular_price > 0
""".strip()


def build_assortment_sql(
    crf_table: str,
    detail_table: str,
    *,
    run_id: str,
    objective: str,
    week_start: str,
    week_end: str,
    plan_rank: int = 1,
    category: str | None = None,
    category_id: str | None = None,
    division_id: str | None = None,
    price_area_cd: str | None = None,
    crf_has_category_id: bool = True,
    detail_has_category_id: bool = True,
    detail_has_division_id: bool = True,
) -> str:
    """Assortment change: one row per item, classified new / continuing / discontinued.

    Items the plan carries that had no sales in the comparable LY weeks are ``new``; items with
    LY sales that the plan does not carry at all are ``discontinued``. Discontinued items have no
    forecast slots, so their LY sales never enter the bridge — this query is what lets the UI
    state the size of that exclusion instead of leaving it as an unexplained gap.
    """
    obj = normalize_objective(objective)
    crf_scope = _scope_predicates(
        category=category, category_id=category_id, price_area_cd=price_area_cd,
        price_area_col="price_area_cd",
        has_category_id=crf_has_category_id, has_division_id=False,
    )
    crf_scope_sql = ("\n    AND " + "\n    AND ".join(crf_scope)) if crf_scope else ""
    detail_scope = _scope_predicates(
        category=category, category_id=category_id, division_id=division_id,
        price_area_cd=price_area_cd,
        has_category_id=detail_has_category_id, has_division_id=detail_has_division_id,
    )
    detail_scope_sql = ("\n    AND " + "\n    AND ".join(detail_scope)) if detail_scope else ""
    return f"""
WITH ly AS (
  SELECT
    CAST(national_common_retail_cd AS STRING) AS item_id,
    SUM(revenue)                                                  AS ly_sales,
    SUM(units)                                                    AS ly_units,
    SUM(revenue - units * ncrc_per_unit_deadnet_cost_x_flat)      AS ly_agp
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'N'
    AND week_start_dt BETWEEN date_sub(DATE {_lit(week_start)}, 364)
                          AND date_sub(DATE {_lit(week_end)}, 364){crf_scope_sql}
  GROUP BY 1
  HAVING SUM(units) > 0
),
plan AS (
  SELECT
    CAST(item_id AS STRING)     AS item_id,
    MAX(item_name)              AS item_name,
    SUM(optimizer_revenue)      AS fy_sales,
    SUM(optimizer_units)        AS fy_units,
    SUM(optimizer_agp)          AS fy_agp
  FROM {detail_table}
  WHERE run_id = {_lit(run_id)}
    AND is_optimizer_selected = true
    AND optimizer_rank = {int(plan_rank)}
    AND UPPER(TRIM(optimizer_objective)) = {_lit(obj)}
    AND UPPER(TRIM(report_objective)) = UPPER(TRIM(optimizer_objective))
    AND week_start_date >= {_lit(week_start)}
    AND week_start_date <= {_lit(week_end)}{detail_scope_sql}
  GROUP BY 1
)
SELECT
  COALESCE(p.item_id, l.item_id) AS item_id,
  p.item_name,
  CASE WHEN l.item_id IS NULL THEN 'new'
       WHEN p.item_id IS NULL THEN 'discontinued'
       ELSE 'continuing' END     AS side,
  COALESCE(l.ly_sales, 0.0)      AS ly_sales,
  COALESCE(l.ly_units, 0.0)      AS ly_units,
  COALESCE(l.ly_agp,   0.0)      AS ly_agp,
  COALESCE(p.fy_sales, 0.0)      AS fy_sales,
  COALESCE(p.fy_units, 0.0)      AS fy_units,
  COALESCE(p.fy_agp,   0.0)      AS fy_agp
FROM plan p
FULL OUTER JOIN ly l ON p.item_id = l.item_id
""".strip()


def build_excluded_ly_context_sql(
    detail_table: str,
    *,
    run_id: str,
    objective: str,
    plan_rank: int = 1,
    category: str,
    division_id: str,
    detail_has_category_id: bool = True,
    detail_has_division_id: bool = True,
) -> str:
    """LY sales excluded from optimizer scope, returned as context for the LY bar only.

    The selected plan supplies the first and last future week. The calendar expands that range
    through six days after the final week start and maps every day to its prior-year date.
    Out-of-scope NCRCs and the single deliberately consolidated ``-1`` NCRC are joined to daily
    sales by UPC x ROG. Nothing returned here enters the additive waterfall calculation.
    """
    obj = normalize_objective(objective)
    detail_preds = [
        f"run_id = {_lit(run_id)}",
        "is_optimizer_selected = true",
        f"optimizer_rank = {int(plan_rank)}",
        f"UPPER(TRIM(optimizer_objective)) = {_lit(obj)}",
        "UPPER(TRIM(report_objective)) = UPPER(TRIM(optimizer_objective))",
    ]
    detail_preds += _scope_predicates(
        category=category, division_id=division_id,
        has_category_id=detail_has_category_id,
        has_division_id=detail_has_division_id,
    )
    detail_where = "\n      AND ".join(detail_preds)

    return f"""
WITH q4_26_bounds AS (
  SELECT
    CAST(division_id AS STRING) AS division_id,
    UPPER(TRIM(category)) AS category,
    MIN(CAST(week_start_date AS DATE)) AS min_future_week,
    MAX(CAST(week_start_date AS DATE)) AS max_future_week
  FROM {detail_table}
  WHERE {detail_where}
  GROUP BY CAST(division_id AS STRING), UPPER(TRIM(category))
),
promo_dates_ly AS (
  SELECT DISTINCT
    q.division_id,
    CAST(pc.calendarDate_prior_year AS DATE) AS ly_transaction_date
  FROM q4_26_bounds q
  INNER JOIN {PROMO_CALENDAR_TABLE} pc
    ON CAST(pc.division_id AS STRING) = q.division_id
   AND CAST(pc.calendarDate AS DATE)
       BETWEEN q.min_future_week AND DATE_ADD(q.max_future_week, 6)
),
excluded_items AS (
  SELECT DISTINCT
    CAST(ih.division_id AS STRING) AS division_id,
    CAST(ih.NATIONAL_COMMON_RETAIL_CD AS STRING) AS national_common_retail_cd,
    CAST(ih.UPC_NBR AS STRING) AS upc_nbr,
    CAST(ih.ROG_ID AS STRING) AS rog_id,
    CASE
      WHEN CAST(ih.NATIONAL_COMMON_RETAIL_CD AS STRING) = '-1'
        THEN 'DISCONTINUED_UNMAPPED'
      ELSE 'OUT_OF_SCOPE'
    END AS exclusion_type
  FROM {ITEM_HIERARCHY_TABLE} ih
  CROSS JOIN q4_26_bounds q
  WHERE CAST(ih.division_id AS STRING) = q.division_id
    AND UPPER(TRIM(ih.category)) = q.category
    AND (
      UPPER(TRIM(CAST(ih.InSCOPE_FLAG AS STRING))) = 'N'
      OR CAST(ih.NATIONAL_COMMON_RETAIL_CD AS STRING) = '-1'
    )
),
excluded_sales AS (
  SELECT
    i.national_common_retail_cd,
    i.exclusion_type,
    SUM(COALESCE(s.NET_AMT, 0.0)) AS ly_sales
  FROM {SALES_COST_ALLOWANCES_TABLE} s
  INNER JOIN excluded_items i
    ON CAST(s.UPC_NBR AS STRING) = i.upc_nbr
   AND CAST(s.ROG_ID AS STRING) = i.rog_id
   AND LPAD(TRIM(CAST(s.DIVISION_ID AS STRING)), 2, '0')
       = LPAD(TRIM(i.division_id), 2, '0')
  INNER JOIN promo_dates_ly d
    ON CAST(s.transaction_dt AS DATE) = d.ly_transaction_date
   AND i.division_id = d.division_id
  GROUP BY i.national_common_retail_cd, i.exclusion_type
)
SELECT
  COUNT(DISTINCT national_common_retail_cd) AS excluded_item_count,
  COUNT(DISTINCT CASE WHEN exclusion_type = 'OUT_OF_SCOPE'
                      THEN national_common_retail_cd END) AS out_of_scope_item_count,
  COUNT(DISTINCT CASE WHEN exclusion_type = 'DISCONTINUED_UNMAPPED'
                      THEN national_common_retail_cd END) AS discontinued_unmapped_item_count,
  SUM(ly_sales) AS excluded_ly_sales,
  SUM(CASE WHEN exclusion_type = 'OUT_OF_SCOPE' THEN ly_sales ELSE 0.0 END)
    AS out_of_scope_ly_sales,
  SUM(CASE WHEN exclusion_type = 'DISCONTINUED_UNMAPPED' THEN ly_sales ELSE 0.0 END)
    AS discontinued_unmapped_ly_sales
FROM excluded_sales
""".strip()


def build_freeze_check_sql(
    crf_table: str,
    *,
    run_id: str,
    category: str | None = None,
    category_id: str | None = None,
    price_area_cd: str | None = None,
    has_category_id: bool = True,
) -> str:
    """Evidence for WHEN (and whether) price and cost were actually frozen.

    Nobody has to remember the freeze date: the last actual week is the derived freeze point, and
    this checks the assumption behind it — if the forecast really holds price and cost flat, each
    item x store carries exactly one regular price and one dead-net cost across all future weeks.
    A share below 1.0 means some items carry planned price/cost changes and are NOT frozen.
    """
    scope = _scope_predicates(
        category=category, category_id=category_id, price_area_cd=price_area_cd,
        price_area_col="price_area_cd",
        has_category_id=has_category_id, has_division_id=False,
    )
    scope_sql = ("\n    AND " + "\n    AND ".join(scope)) if scope else ""
    return f"""
WITH fut AS (
  SELECT
    CAST(national_common_retail_cd AS STRING) AS item_id,
    CAST(facility_integration_id AS STRING)   AS facility_integration_id,
    week_start_dt,
    regular_price,
    ncrc_per_unit_deadnet_cost_x_flat         AS deadnet
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'Y'{scope_sql}
),
per_combo AS (
  SELECT item_id, facility_integration_id,
         COUNT(DISTINCT regular_price) AS price_levels,
         COUNT(DISTINCT deadnet)       AS cost_levels
  FROM fut
  GROUP BY 1, 2
),
actuals AS (
  SELECT MAX(week_start_dt) AS last_actual_week
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'N'{scope_sql}
)
SELECT
  (SELECT CAST(last_actual_week AS STRING) FROM actuals)        AS last_actual_week,
  (SELECT CAST(MIN(week_start_dt) AS STRING) FROM fut)          AS first_future_week,
  (SELECT COUNT(DISTINCT week_start_dt) FROM fut)               AS future_weeks,
  COUNT(*)                                                      AS item_store_combos,
  SUM(CASE WHEN price_levels = 1 THEN 1 ELSE 0 END)             AS flat_price_combos,
  SUM(CASE WHEN cost_levels  = 1 THEN 1 ELSE 0 END)             AS flat_cost_combos
FROM per_combo
""".strip()


def build_price_elasticity_sql(
    crf_table: str,
    *,
    run_id: str,
    category: str | None = None,
    category_id: str | None = None,
    price_area_cd: str | None = None,
    digital_depth_col: str = DEFAULT_DIGITAL_DEPTH_COL,
    has_category_id: bool = True,
    history_weeks: int = 104,
) -> str:
    """Historical regular-price elasticity of demand: for every 1% regular-price change, how did
    units respond? Weighted OLS slope of ln(units YoY ratio) on ln(price YoY ratio) over matched
    item x store x week pairs that are non-promoted in both periods (so promo lifts don't
    contaminate the price response). Returns the raw regression sums; the slope is assembled in
    ``elasticity_from_row``. Weight = prior-period units.

    ``history_weeks`` bounds how far back the CURRENT side of each pair reaches from the last
    actual week; the prior side is that window shifted back 364 days, so the scan covers
    ``history_weeks + 52`` weeks in total. Left unbounded this is a self-join over the entire
    retained history at item x store x week and becomes the slowest query in the payload."""
    scope = _scope_predicates(
        category=category, category_id=category_id, price_area_cd=price_area_cd,
        price_area_col="price_area_cd",
        has_category_id=has_category_id, has_division_id=False,
    )
    scope_sql = ("\n    AND " + "\n    AND ".join(scope)) if scope else ""
    nonpromo = " AND ".join(
        f"COALESCE({col}, 0.0) = 0.0" for col in (*STORE_DEPTH_COLS, digital_depth_col)
    )
    return f"""
WITH bounded AS (
  SELECT
    CAST(national_common_retail_cd AS STRING) AS item_id,
    CAST(price_area_cd AS STRING)     AS price_area_cd,
    CAST(facility_integration_id AS STRING)   AS facility_integration_id,
    week_start_dt,
    units,
    regular_price
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'N'
    AND regular_price > 0
    AND units > 0
    AND ({nonpromo}){scope_sql}
),
maxw AS (SELECT MAX(week_start_dt) AS mx FROM bounded),
hist AS (
  SELECT b.* FROM bounded b CROSS JOIN maxw
  WHERE b.week_start_dt > date_sub(maxw.mx, ({int(history_weeks)} + 52) * 7)
),
pairs AS (
  SELECT
    p.units                          AS w,
    LN(c.regular_price / p.regular_price) AS x,
    LN(c.units / p.units)            AS y
  FROM hist c
  CROSS JOIN maxw
  JOIN hist p
    ON c.item_id = p.item_id
   AND c.facility_integration_id = p.facility_integration_id
   AND COALESCE(c.price_area_cd, '') = COALESCE(p.price_area_cd, '')
   AND p.week_start_dt = date_sub(c.week_start_dt, 364)
  WHERE c.week_start_dt > date_sub(maxw.mx, {int(history_weeks)} * 7)
)
SELECT
  COUNT(*)       AS matched_pairs,
  SUM(w)         AS sw,
  SUM(w * x)     AS swx,
  SUM(w * y)     AS swy,
  SUM(w * x * y) AS swxy,
  SUM(w * x * x) AS swxx
FROM pairs
""".strip()


def build_trend_sql(
    crf_table: str,
    detail_table: str,
    *,
    run_id: str,
    objective: str,
    week_start: str,
    week_end: str,
    plan_rank: int = 1,
    category: str | None = None,
    category_id: str | None = None,
    division_id: str | None = None,
    price_area_cd: str | None = None,
    crf_has_category_id: bool = True,
    detail_has_category_id: bool = True,
    detail_has_division_id: bool = True,
) -> str:
    """Aggregate metric-specific YoY category growth after the LY-plan anchor through freeze.

    The maximum comparable-LY week from the selected future plan is the anchor. All actual
    category items and promotion states contribute to weekly sales, units, and AGP. Post-anchor
    actual totals through the freeze week are divided by the corresponding totals for the same
    matched weeks 364 days earlier. Sales, units, and AGP return independent one-time
    multipliers. The category-wide trend is still computed when the waterfall request is
    item-scoped.
    """
    obj = normalize_objective(objective)
    crf_scope = _scope_predicates(
        category=category, category_id=category_id, price_area_cd=price_area_cd,
        price_area_col="price_area_cd",
        has_category_id=crf_has_category_id, has_division_id=False,
    )
    crf_scope_sql = ("\n      AND " + "\n      AND ".join(crf_scope)) if crf_scope else ""

    detail_preds = [
        f"run_id = {_lit(run_id)}",
        "is_optimizer_selected = true",
        f"optimizer_rank = {int(plan_rank)}",
        f"UPPER(TRIM(optimizer_objective)) = {_lit(obj)}",
        "UPPER(TRIM(report_objective)) = UPPER(TRIM(optimizer_objective))",
    ]
    detail_preds += _scope_predicates(
        category=category, category_id=category_id, division_id=division_id,
        price_area_cd=price_area_cd,
        has_category_id=detail_has_category_id, has_division_id=detail_has_division_id,
    )
    detail_preds += [
        f"CAST(week_start_date AS DATE) >= DATE {_lit(week_start)}",
        f"CAST(week_start_date AS DATE) <= DATE {_lit(week_end)}",
    ]
    detail_where = "\n      AND ".join(detail_preds)

    return f"""
WITH future_plan_weeks AS (
  SELECT DISTINCT CAST(week_start_date AS DATE) AS future_week
  FROM {detail_table}
  WHERE {detail_where}
),
plan_bounds AS (
  SELECT
    MIN(future_week)                         AS future_start_week,
    MAX(future_week)                         AS future_end_week,
    MIN(DATE_SUB(future_week, 364))          AS ly_start_week,
    MAX(DATE_SUB(future_week, 364))          AS ly_end_week,
    MAX(DATE_SUB(future_week, 364))          AS anchor_week
  FROM future_plan_weeks
),
actual_weekly AS (
  SELECT
    CAST(week_start_dt AS DATE) AS week_start_dt,
    SUM(COALESCE(revenue, 0.0)) AS weekly_sales,
    SUM(COALESCE(units, 0.0))   AS weekly_units,
    SUM(
      COALESCE(revenue, 0.0)
      - COALESCE(units, 0.0) * COALESCE(ncrc_per_unit_deadnet_cost_x_flat, 0.0)
    ) AS weekly_agp
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'N'{crf_scope_sql}
  GROUP BY CAST(week_start_dt AS DATE)
),
actual_bounds AS (
  SELECT MAX(week_start_dt) AS freeze_week
  FROM actual_weekly
),
matched_period_weeks AS (
  SELECT
    c.week_start_dt,
    c.weekly_sales AS current_week_sales,
    y.weekly_sales AS year_ago_week_sales,
    c.weekly_units AS current_week_units,
    y.weekly_units AS year_ago_week_units,
    c.weekly_agp AS current_week_agp,
    y.weekly_agp AS year_ago_week_agp
  FROM actual_weekly c
  JOIN actual_weekly y
    ON y.week_start_dt = DATE_SUB(c.week_start_dt, 364)
  CROSS JOIN plan_bounds p
  CROSS JOIN actual_bounds f
  WHERE p.anchor_week IS NOT NULL
    AND f.freeze_week IS NOT NULL
    AND c.week_start_dt > p.anchor_week
    AND c.week_start_dt <= f.freeze_week
    AND c.weekly_units > 0
    AND y.weekly_units > 0
),
period_summary AS (
  SELECT
    COUNT(*)                    AS observed_growth_weeks,
    MIN(week_start_dt)          AS trend_window_start,
    MAX(week_start_dt)          AS trend_window_end,
    SUM(current_week_sales)     AS frozen_period_sales,
    SUM(year_ago_week_sales)    AS ly_same_period_sales,
    SUM(current_week_units)     AS frozen_period_units,
    SUM(year_ago_week_units)    AS ly_same_period_units,
    SUM(current_week_agp)       AS frozen_period_agp,
    SUM(year_ago_week_agp)      AS ly_same_period_agp
  FROM matched_period_weeks
)
SELECT
  p.future_start_week,
  p.future_end_week,
  p.ly_start_week,
  p.ly_end_week,
  p.anchor_week,
  a.freeze_week,
  g.observed_growth_weeks,
  g.trend_window_start,
  g.trend_window_end,
  g.frozen_period_sales,
  g.ly_same_period_sales,
  g.frozen_period_units,
  g.ly_same_period_units,
  g.frozen_period_agp,
  g.ly_same_period_agp,
  CASE WHEN g.ly_same_period_sales > 0
       THEN g.frozen_period_sales / g.ly_same_period_sales - 1.0
       END AS sales_period_yoy_growth,
  CASE WHEN g.ly_same_period_sales > 0
       THEN g.frozen_period_sales / g.ly_same_period_sales
       END AS sales_trend_ratio,
  CASE WHEN g.ly_same_period_units > 0
       THEN g.frozen_period_units / g.ly_same_period_units - 1.0
       END AS units_period_yoy_growth,
  CASE WHEN g.ly_same_period_units > 0
       THEN g.frozen_period_units / g.ly_same_period_units
       END AS units_trend_ratio,
  CASE WHEN g.ly_same_period_agp > 0
       THEN g.frozen_period_agp / g.ly_same_period_agp - 1.0
       END AS agp_period_yoy_growth,
  CASE WHEN g.ly_same_period_agp > 0
       THEN g.frozen_period_agp / g.ly_same_period_agp
       END AS agp_trend_ratio,
  -- Compatibility aliases retain the former units-based result contract.
  CASE WHEN g.ly_same_period_units > 0
       THEN g.frozen_period_units / g.ly_same_period_units - 1.0
       END AS period_yoy_growth,
  CASE WHEN g.ly_same_period_units > 0
       THEN g.frozen_period_units / g.ly_same_period_units - 1.0
       END AS average_yoy_growth,
  CASE WHEN g.ly_same_period_units > 0
       THEN g.frozen_period_units / g.ly_same_period_units
       END AS trend_ratio
FROM period_summary g
CROSS JOIN plan_bounds p
CROSS JOIN actual_bounds a
""".strip()


def _build_trend_momentum_sql_legacy(
    crf_table: str,
    detail_table: str,
    *,
    run_id: str,
    objective: str,
    week_start: str,
    week_end: str,
    plan_rank: int = 1,
    category: str | None = None,
    category_id: str | None = None,
    division_id: str | None = None,
    price_area_cd: str | None = None,
    crf_has_category_id: bool = True,
    detail_has_category_id: bool = True,
    detail_has_division_id: bool = True,
) -> str:
    """Project post-freeze momentum by scaling the actual LY Q4 seasonal path.

    Weekly sales, units, and AGP are aggregated across all category items and promo states.
    Each selected future Q4 week takes its corresponding LY actual and scales it by the ratio
    of the current freeze-week actual to the corresponding LY freeze week. This preserves the
    observed Q4 seasonal decline without averaging or compounding volatile weekly growth rates.
    """
    obj = normalize_objective(objective)
    crf_scope = _scope_predicates(
        category=category, category_id=category_id, price_area_cd=price_area_cd,
        price_area_col="price_area_cd",
        has_category_id=crf_has_category_id, has_division_id=False,
    )
    crf_scope_sql = ("\n      AND " + "\n      AND ".join(crf_scope)) if crf_scope else ""

    detail_preds = [
        f"run_id = {_lit(run_id)}",
        "is_optimizer_selected = true",
        f"optimizer_rank = {int(plan_rank)}",
        f"UPPER(TRIM(optimizer_objective)) = {_lit(obj)}",
        "UPPER(TRIM(report_objective)) = UPPER(TRIM(optimizer_objective))",
    ]
    detail_preds += _scope_predicates(
        category=category, category_id=category_id, division_id=division_id,
        price_area_cd=price_area_cd,
        has_category_id=detail_has_category_id, has_division_id=detail_has_division_id,
    )
    detail_preds += [
        f"CAST(week_start_date AS DATE) >= DATE {_lit(week_start)}",
        f"CAST(week_start_date AS DATE) <= DATE {_lit(week_end)}",
    ]
    detail_where = "\n      AND ".join(detail_preds)

    return f"""
WITH future_plan_weeks AS (
  SELECT DISTINCT CAST(week_start_date AS DATE) AS future_week
  FROM {detail_table}
  WHERE {detail_where}
),
plan_bounds AS (
  SELECT
    MIN(future_week) AS future_start_week,
    MAX(future_week) AS future_end_week,
    COUNT(*) AS expected_q4_weeks
  FROM future_plan_weeks
),
actual_weekly AS (
  SELECT
    CAST(week_start_dt AS DATE) AS week_start_dt,
    SUM(COALESCE(revenue, 0.0)) AS weekly_sales,
    SUM(COALESCE(units, 0.0)) AS weekly_units,
    SUM(
      COALESCE(revenue, 0.0)
      - COALESCE(units, 0.0) * COALESCE(ncrc_per_unit_deadnet_cost_x_flat, 0.0)
    ) AS weekly_agp
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'N'{crf_scope_sql}
  GROUP BY CAST(week_start_dt AS DATE)
),
actual_bounds AS (
  SELECT MAX(week_start_dt) AS freeze_week
  FROM actual_weekly
),
freeze_values AS (
  SELECT
    w.weekly_sales AS freeze_week_sales,
    w.weekly_units AS freeze_week_units,
    w.weekly_agp AS freeze_week_agp
  FROM actual_weekly w
  CROSS JOIN actual_bounds a
  WHERE w.week_start_dt = a.freeze_week
),
ly_freeze_values AS (
  SELECT
    w.weekly_sales AS ly_freeze_week_sales,
    w.weekly_units AS ly_freeze_week_units,
    w.weekly_agp AS ly_freeze_week_agp
  FROM actual_weekly w
  CROSS JOIN actual_bounds a
  WHERE w.week_start_dt = DATE_SUB(a.freeze_week, 364)
),
projected_path AS (
  SELECT
    fw.future_week AS projected_week,
    ly.weekly_sales AS ly_week_sales,
    ly.weekly_units AS ly_week_units,
    ly.weekly_agp AS ly_week_agp,
    CASE WHEN lf.ly_freeze_week_sales > 0
         THEN f.freeze_week_sales
              * ly.weekly_sales / lf.ly_freeze_week_sales END AS projected_sales,
    CASE WHEN lf.ly_freeze_week_units > 0
         THEN f.freeze_week_units
              * ly.weekly_units / lf.ly_freeze_week_units END AS projected_units,
    CASE WHEN lf.ly_freeze_week_agp > 0
         THEN f.freeze_week_agp
              * ly.weekly_agp / lf.ly_freeze_week_agp END AS projected_agp
  FROM future_plan_weeks fw
  INNER JOIN actual_weekly ly
    ON ly.week_start_dt = DATE_SUB(fw.future_week, 364)
  CROSS JOIN freeze_values f
  CROSS JOIN ly_freeze_values lf
),
momentum_summary AS (
  SELECT
    COUNT(*) AS projected_q4_weeks,
    SUM(p.projected_sales) AS momentum_projected_q4_sales,
    SUM(p.projected_units) AS momentum_projected_q4_units,
    SUM(p.projected_agp) AS momentum_projected_q4_agp
  FROM projected_path p
),
ly_q4_summary AS (
  SELECT
    SUM(a.weekly_sales) AS momentum_ly_q4_sales,
    SUM(a.weekly_units) AS momentum_ly_q4_units,
    SUM(a.weekly_agp) AS momentum_ly_q4_agp
  FROM actual_weekly a
  INNER JOIN future_plan_weeks f
    ON a.week_start_dt = DATE_SUB(f.future_week, 364)
)
SELECT
  p.future_start_week,
  p.future_end_week,
  p.expected_q4_weeks,
  a.freeze_week,
  f.freeze_week_sales,
  f.freeze_week_units,
  f.freeze_week_agp,
  lf.ly_freeze_week_sales,
  lf.ly_freeze_week_units,
  lf.ly_freeze_week_agp,
  m.projected_q4_weeks,
  m.momentum_projected_q4_sales,
  m.momentum_projected_q4_units,
  m.momentum_projected_q4_agp,
  y.momentum_ly_q4_sales,
  y.momentum_ly_q4_units,
  y.momentum_ly_q4_agp,
  CASE WHEN y.momentum_ly_q4_sales > 0
       THEN m.momentum_projected_q4_sales / y.momentum_ly_q4_sales END
    AS momentum_sales_ratio,
  CASE WHEN y.momentum_ly_q4_units > 0
       THEN m.momentum_projected_q4_units / y.momentum_ly_q4_units END
    AS momentum_units_ratio,
  CASE WHEN y.momentum_ly_q4_agp <> 0
       THEN m.momentum_projected_q4_agp / y.momentum_ly_q4_agp END
    AS momentum_agp_ratio
FROM momentum_summary m
CROSS JOIN ly_q4_summary y
CROSS JOIN plan_bounds p
CROSS JOIN actual_bounds a
CROSS JOIN freeze_values f
CROSS JOIN ly_freeze_values lf
""".strip()


def build_trend_momentum_sql(
    crf_table: str,
    detail_table: str,
    *,
    run_id: str,
    objective: str,
    week_start: str,
    week_end: str,
    plan_rank: int = 1,
    category: str | None = None,
    category_id: str | None = None,
    division_id: str | None = None,
    price_area_cd: str | None = None,
    crf_has_category_id: bool = True,
    detail_has_category_id: bool = True,
    detail_has_division_id: bool = True,
) -> str:
    """Weekly three-year CRF history used by the Python STL momentum calculation."""
    obj = normalize_objective(objective)
    crf_scope = _scope_predicates(
        category=category, category_id=category_id, price_area_cd=price_area_cd,
        price_area_col="price_area_cd",
        has_category_id=crf_has_category_id, has_division_id=False,
    )
    crf_scope_sql = ("\n      AND " + "\n      AND ".join(crf_scope)) if crf_scope else ""
    detail_preds = [
        f"run_id = {_lit(run_id)}",
        "is_optimizer_selected = true",
        f"optimizer_rank = {int(plan_rank)}",
        f"UPPER(TRIM(optimizer_objective)) = {_lit(obj)}",
        "UPPER(TRIM(report_objective)) = UPPER(TRIM(optimizer_objective))",
    ]
    detail_preds += _scope_predicates(
        category=category, category_id=category_id, division_id=division_id,
        price_area_cd=price_area_cd,
        has_category_id=detail_has_category_id,
        has_division_id=detail_has_division_id,
    )
    detail_preds += [
        f"CAST(week_start_date AS DATE) >= DATE {_lit(week_start)}",
        f"CAST(week_start_date AS DATE) <= DATE {_lit(week_end)}",
    ]
    detail_where = "\n      AND ".join(detail_preds)
    return f"""
WITH future_plan_weeks AS (
  SELECT DISTINCT CAST(week_start_date AS DATE) AS future_week
  FROM {detail_table}
  WHERE {detail_where}
),
plan_bounds AS (
  SELECT
    MIN(future_week) AS future_start_week,
    MAX(future_week) AS future_end_week,
    COUNT(*) AS expected_q4_weeks
  FROM future_plan_weeks
),
actual_weekly AS (
  SELECT
    CAST(week_start_dt AS DATE) AS week_start_date,
    SUM(COALESCE(revenue, 0.0)) AS weekly_sales,
    SUM(COALESCE(units, 0.0)) AS weekly_units,
    SUM(
      COALESCE(revenue, 0.0)
      - COALESCE(units, 0.0)
        * COALESCE(ncrc_per_unit_deadnet_cost_x_flat, 0.0)
    ) AS weekly_agp
  FROM {crf_table}
  WHERE run_id = {_lit(run_id)}
    AND future_data_flag = 'N'{crf_scope_sql}
  GROUP BY CAST(week_start_dt AS DATE)
),
actual_bounds AS (
  SELECT MAX(week_start_date) AS freeze_week
  FROM actual_weekly
)
SELECT
  w.week_start_date,
  w.weekly_sales,
  w.weekly_units,
  w.weekly_agp,
  p.future_start_week,
  p.future_end_week,
  p.expected_q4_weeks,
  a.freeze_week
FROM actual_weekly w
CROSS JOIN plan_bounds p
CROSS JOIN actual_bounds a
WHERE w.week_start_date BETWEEN DATE_SUB(a.freeze_week, 3 * 364) AND a.freeze_week
ORDER BY w.week_start_date
""".strip()


# ---------------------------------------------------------------------------
# Bridge computation (pure pandas)
# ---------------------------------------------------------------------------

def _num(series: pd.Series | None, index: pd.Index) -> pd.Series:
    if series is None:
        return pd.Series(0.0, index=index)
    return pd.to_numeric(series, errors="coerce").fillna(0.0).astype(float)


def trend_ratio_from_row(
    trend_row: dict | None,
    metric: str = "units",
) -> tuple[float | None, dict]:
    """Aggregate frozen-period YoY category multiplier for one metric.

    Metric-specific fields are preferred. The former units-only result shape remains a fallback
    for stored payloads and callers created before sales and AGP received independent trends.
    """
    metric = str(metric).lower()
    if metric not in METRICS:
        raise ValueError(f"Unsupported trend metric: {metric!r}")
    diag: dict[str, Any] = {"observed_growth_weeks": 0}
    if not trend_row:
        return None, diag
    diag = {k: trend_row.get(k) for k in (
        "future_start_week", "future_end_week", "ly_start_week", "ly_end_week",
        "anchor_week", "freeze_week", "observed_growth_weeks", "trend_window_start",
        "trend_window_end",
        "frozen_period_sales", "ly_same_period_sales", "sales_period_yoy_growth",
        "sales_trend_ratio", "frozen_period_units", "ly_same_period_units",
        "units_period_yoy_growth", "units_trend_ratio", "frozen_period_agp",
        "ly_same_period_agp", "agp_period_yoy_growth", "agp_trend_ratio",
        "period_yoy_growth", "average_yoy_growth", "trend_ratio",
    )}
    diag["metric"] = metric

    ratio_key = f"{metric}_trend_ratio"
    # Compatibility: a row without metric-specific fields came from the former contract, where
    # the unsuffixed units ratio was applied to all three waterfall metrics.
    ratio_raw = (
        trend_row.get(ratio_key)
        if ratio_key in trend_row
        else trend_row.get("trend_ratio")
    )
    observed_raw = trend_row.get("observed_growth_weeks")
    if ratio_raw is not None and not pd.isna(ratio_raw):
        observed = 0 if observed_raw is None or pd.isna(observed_raw) else int(observed_raw)
        ratio = float(ratio_raw)
        if observed <= 0 or ratio <= 0.0:
            return None, diag
        return ratio, diag

    # Compatibility with the previous matched YoY trend-row contract.
    old_diag = {k: trend_row.get(k) for k in (
        "matched_pairs", "cur_units", "prior_units", "cur_sales", "prior_sales",
        "cur_agp", "prior_agp", "trend_window_start", "trend_window_end",
    )}
    prior = float(trend_row.get(f"prior_{metric}") or 0.0)
    cur = float(trend_row.get(f"cur_{metric}") or 0.0)
    if prior <= 0.0 or int(trend_row.get("matched_pairs") or 0) <= 0:
        return None, old_diag
    return cur / prior, old_diag


def momentum_ratio_from_row(
    momentum_row: dict | None,
    metric: str,
) -> tuple[float | None, dict]:
    """Return the category projected-Q4 / LY-Q4 momentum ratio for one metric."""
    metric = str(metric).lower()
    if metric not in METRICS:
        raise ValueError(f"Unsupported momentum metric: {metric!r}")
    diag = {k: momentum_row.get(k) if momentum_row else None for k in (
        "future_start_week", "future_end_week", "expected_q4_weeks", "freeze_week",
        "freeze_week_sales", "freeze_week_units", "freeze_week_agp",
        "ly_freeze_week_sales", "ly_freeze_week_units", "ly_freeze_week_agp",
        "projected_q4_weeks",
        "momentum_projected_q4_sales", "momentum_projected_q4_units",
        "momentum_projected_q4_agp", "momentum_ly_q4_sales", "momentum_ly_q4_units",
        "momentum_ly_q4_agp", "momentum_sales_ratio", "momentum_units_ratio",
        "momentum_agp_ratio",
    )}
    if momentum_row:
        diag.update({
            k: v for k, v in momentum_row.items()
            if k == "method" or k.startswith("stl_")
        })
    diag["metric"] = metric
    if not momentum_row:
        return None, diag
    weeks_raw = momentum_row.get("projected_q4_weeks")
    weeks = 0 if weeks_raw is None or pd.isna(weeks_raw) else int(weeks_raw)
    expected_raw = momentum_row.get("expected_q4_weeks")
    expected = 0 if expected_raw is None or pd.isna(expected_raw) else int(expected_raw)
    value = momentum_row.get(f"momentum_{metric}_ratio")
    if expected <= 0 or weeks != expected or value is None or pd.isna(value):
        return None, diag
    return float(value), diag


def stl_momentum_from_weekly(
    weekly: pd.DataFrame | None,
    *,
    frozen_weeks: int = 16,
) -> dict | None:
    """Derive metric-specific Q4 momentum ratios from three years of weekly CRF actuals.

    STL is fitted to the complete weekly sales, units, and AGP series through the freeze week.
    The latest frozen-period trend level is compared with the same weeks LY and LY-LY. The
    selected seasonally adjusted rate reflects stable/accelerating/decelerating/inflecting
    movement; ``compute_waterfall`` subsequently subtracts the already-attributed category
    trend ratio, leaving only incremental momentum in the bar.
    """
    if weekly is None or weekly.empty:
        return None
    required = {
        "week_start_date", "weekly_sales", "weekly_units", "weekly_agp",
        "future_start_week", "future_end_week", "expected_q4_weeks", "freeze_week",
    }
    missing = required - {str(c).lower() for c in weekly.columns}
    if missing:
        raise ValueError(f"STL momentum input is missing columns: {sorted(missing)}")

    from statsmodels.tsa.seasonal import STL

    frame = weekly.copy()
    frame.columns = [str(c).lower() for c in frame.columns]
    frame["week_start_date"] = pd.to_datetime(frame["week_start_date"], errors="coerce")
    frame = frame.dropna(subset=["week_start_date"]).sort_values("week_start_date")
    frame = frame.drop_duplicates("week_start_date", keep="last").set_index("week_start_date")
    if frame.empty:
        return None

    freeze_week = pd.Timestamp(frame["freeze_week"].dropna().iloc[0]).normalize()
    frame = frame.loc[frame.index <= freeze_week]
    complete_index = pd.date_range(frame.index.min(), freeze_week, freq="7D")
    missing_weeks = complete_index.difference(frame.index)
    if len(missing_weeks):
        raise ValueError(
            f"STL momentum requires a complete weekly series; {len(missing_weeks)} weeks missing"
        )
    frame = frame.reindex(complete_index)
    if len(frame) < 120:
        raise ValueError(
            f"STL momentum requires at least 120 weekly observations; received {len(frame)}"
        )

    expected_weeks = int(frame["expected_q4_weeks"].dropna().iloc[0])
    future_start = pd.Timestamp(frame["future_start_week"].dropna().iloc[0]).normalize()
    future_end = pd.Timestamp(frame["future_end_week"].dropna().iloc[0]).normalize()
    future_dates = pd.date_range(future_start, future_end, freq="7D")
    if expected_weeks <= 0:
        raise ValueError(
            "STL momentum future-week range does not match expected_q4_weeks: "
            f"{len(future_dates)} versus {expected_weeks}"
        )

    current_dates = frame.index[-int(frozen_weeks):]
    if len(current_dates) != int(frozen_weeks):
        raise ValueError("STL momentum has fewer frozen-period weeks than requested")
    ly_dates = current_dates - pd.Timedelta(days=364)
    l2y_dates = current_dates - pd.Timedelta(days=728)
    needed_dates = ly_dates.union(l2y_dates)
    absent_comparisons = needed_dates.difference(frame.index)
    if len(absent_comparisons):
        raise ValueError(
            "STL momentum lacks corresponding LY/LY-LY comparison weeks: "
            f"{len(absent_comparisons)} missing"
        )

    result: dict[str, Any] = {
        "method": "stl_three_year",
        "future_start_week": str(future_start.date()),
        "future_end_week": str(future_end.date()),
        "expected_q4_weeks": expected_weeks,
        "projected_q4_weeks": expected_weeks,
        "freeze_week": str(freeze_week.date()),
        "stl_history_start": str(frame.index.min().date()),
        "stl_history_end": str(frame.index.max().date()),
        "stl_history_weeks": int(len(frame)),
        "stl_frozen_weeks": int(frozen_weeks),
        "stl_current_window_start": str(current_dates.min().date()),
        "stl_current_window_end": str(current_dates.max().date()),
        "stl_trajectory": {},
    }

    for metric in METRICS:
        column = f"weekly_{metric}"
        values = pd.to_numeric(frame[column], errors="coerce")
        if values.isna().any():
            raise ValueError(f"STL momentum {column} contains null weekly observations")
        fitted = STL(values.to_numpy(), period=52, seasonal=13, robust=True).fit()
        trend = pd.Series(fitted.trend, index=frame.index, dtype=float)
        residual = pd.Series(fitted.resid, index=frame.index, dtype=float)

        current_level = float(trend.reindex(current_dates).mean())
        ly_level = float(trend.reindex(ly_dates).mean())
        l2y_level = float(trend.reindex(l2y_dates).mean())
        if ly_level <= 0.0 or l2y_level <= 0.0:
            result[f"momentum_{metric}_ratio"] = None
            continue

        current_rate = current_level / ly_level - 1.0
        prior_rate = ly_level / l2y_level - 1.0
        rate_change = current_rate - prior_rate
        trend_range = float(trend.max() - trend.min())
        residual_std = float(residual.std())
        damping = 0.5 if trend_range <= 0.0 else max(
            0.5, min(0.9, 1.0 - residual_std / trend_range)
        )
        signs_differ = current_rate * prior_rate < 0.0
        if signs_differ:
            trajectory = "inflecting_up" if current_rate > 0.0 else "inflecting_down"
            selected_rate = current_rate * damping
        elif abs(rate_change) < 0.005:
            trajectory = "stable"
            selected_rate = current_rate
        elif rate_change > 0.0:
            trajectory = "accelerating"
            selected_rate = current_rate
        else:
            trajectory = "decelerating"
            selected_rate = 0.80 * current_rate + 0.20 * prior_rate

        stability_base = max(abs(prior_rate), abs(current_rate), 0.001)
        stability = max(0.0, 1.0 - abs(rate_change) / stability_base)
        ratio = 1.0 + selected_rate
        ly_q4_dates = future_dates - pd.Timedelta(days=364)
        ly_q4 = pd.to_numeric(frame[column].reindex(ly_q4_dates), errors="coerce")
        ly_q4_total = float(ly_q4.sum()) if not ly_q4.isna().any() else None

        result.update({
            f"momentum_{metric}_ratio": ratio,
            f"momentum_ly_q4_{metric}": ly_q4_total,
            f"momentum_projected_q4_{metric}": (
                ly_q4_total * ratio if ly_q4_total is not None else None
            ),
            f"stl_current_{metric}_level": current_level,
            f"stl_ly_{metric}_level": ly_level,
            f"stl_l2y_{metric}_level": l2y_level,
            f"stl_current_{metric}_rate": current_rate,
            f"stl_prior_{metric}_rate": prior_rate,
            f"stl_{metric}_rate_change": rate_change,
            f"stl_selected_{metric}_rate": selected_rate,
            f"stl_{metric}_damping": damping,
            f"stl_{metric}_stability": stability,
        })
        result["stl_trajectory"][metric] = trajectory

    return result


def drift_from_row(drift_row: dict | None) -> dict | None:
    """Annual regular-price / dead-net-cost drift rates and the freeze week from one aggregated
    price-drift-SQL row; None when not computable."""
    if not drift_row or not int(drift_row.get("matched_pairs") or 0):
        return None
    prior_price = float(drift_row.get("prior_wavg_price") or 0.0)
    cur_price = float(drift_row.get("cur_wavg_price") or 0.0)
    prior_cost = float(drift_row.get("prior_wavg_deadnet") or 0.0)
    cur_cost = float(drift_row.get("cur_wavg_deadnet") or 0.0)
    freeze_week = drift_row.get("freeze_week")
    if prior_price <= 0.0 or not freeze_week:
        return None
    return {
        "price_drift_annual": cur_price / prior_price - 1.0,
        "cost_drift_annual": (cur_cost / prior_cost - 1.0) if prior_cost > 0.0 else 0.0,
        "freeze_week": str(freeze_week)[:10],
        "matched_pairs": int(drift_row.get("matched_pairs") or 0),
    }


def summarize_assortment(assortment: pd.DataFrame | None, *, top_n: int = 10) -> dict | None:
    """Counts and $ / unit / AGP impact of items added and dropped versus the LY comparison.

    ``ly_not_in_plan`` is the reconciling figure the UI should be able to quote: discontinued
    items carry LY sales but have no forecast slots, so that amount sits outside the bridge.
    """
    required = {"side", "ly_sales", "ly_units", "ly_agp", "fy_sales", "fy_units", "fy_agp"}
    if assortment is None or assortment.empty or not required <= set(assortment.columns):
        return None
    df = assortment.copy()
    for col in ("ly_sales", "ly_units", "ly_agp", "fy_sales", "fy_units", "fy_agp"):
        df[col] = _num(df.get(col), df.index)
    df["side"] = df["side"].astype(str)

    def _block(mask: pd.Series, prefix: str) -> dict[str, Any]:
        rows = df[mask]
        return {
            "items": int(rows.shape[0]),
            "sales": float(rows[f"{prefix}_sales"].sum()),
            "units": float(rows[f"{prefix}_units"].sum()),
            "agp": float(rows[f"{prefix}_agp"].sum()),
        }

    is_new = df["side"] == "new"
    is_disc = df["side"] == "discontinued"
    is_cont = df["side"] == "continuing"

    new_block = _block(is_new, "fy")
    disc_block = _block(is_disc, "ly")
    cont_ly = _block(is_cont, "ly")
    cont_fy = _block(is_cont, "fy")

    def _top(rows: pd.DataFrame, prefix: str) -> list[dict[str, Any]]:
        cols = ["item_id", "item_name", f"{prefix}_sales", f"{prefix}_units", f"{prefix}_agp"]
        out = rows.reindex(columns=cols).copy()
        out = out.rename(columns={f"{prefix}_sales": "sales", f"{prefix}_units": "units",
                                  f"{prefix}_agp": "agp"})
        out = out.sort_values("sales", ascending=False).head(top_n)
        return out.to_dict(orient="records")

    total_ly_full = float(df["ly_sales"].sum())
    return {
        "new_items": new_block,
        "discontinued_items": disc_block,
        "continuing_items": {**cont_ly, "fy_sales": cont_fy["sales"],
                             "fy_units": cont_fy["units"], "fy_agp": cont_fy["agp"]},
        # Full LY category versus the slice the bridge starts from.
        "ly_total_all_items": total_ly_full,
        "ly_not_in_plan": disc_block["sales"],
        "ly_not_in_plan_share": (disc_block["sales"] / total_ly_full) if total_ly_full else None,
        "new_share_of_forecast": None,
        "top_new_items": _top(df[is_new], "fy"),
        "top_discontinued_items": _top(df[is_disc], "ly"),
    }


def summarize_excluded_ly_context(excluded_ly: pd.DataFrame | None) -> dict | None:
    """Normalize the one-row excluded-LY query result for context above the sales LY bar."""
    required = {
        "excluded_item_count", "out_of_scope_item_count",
        "discontinued_unmapped_item_count", "excluded_ly_sales",
        "out_of_scope_ly_sales", "discontinued_unmapped_ly_sales",
    }
    if excluded_ly is None or excluded_ly.empty or not required <= set(excluded_ly.columns):
        return None
    row = excluded_ly.iloc[0]

    def _number(key: str) -> float:
        value = row.get(key)
        return 0.0 if value is None or pd.isna(value) else float(value)

    return {
        "context_only": True,
        "excluded_item_count": int(_number("excluded_item_count")),
        "out_of_scope_item_count": int(_number("out_of_scope_item_count")),
        "discontinued_unmapped_item_count": int(
            _number("discontinued_unmapped_item_count")
        ),
        "excluded_ly_sales": _number("excluded_ly_sales"),
        "out_of_scope_ly_sales": _number("out_of_scope_ly_sales"),
        "discontinued_unmapped_ly_sales": _number("discontinued_unmapped_ly_sales"),
    }


def assortment_note(payload: dict, metric: str = "sales") -> str | None:
    """One-line footer for the UI: what the plan added and dropped versus last year."""
    a = payload.get("assortment")
    if not a:
        return None
    new = a["new_items"]
    disc = a["discontinued_items"]
    if not new["items"] and not disc["items"]:
        return "Like-for-like assortment: no items added or dropped versus last year."
    parts = []
    if new["items"]:
        parts.append(f"{new['items']} newly listed item{'s' if new['items'] != 1 else ''} "
                     f"contributing {format_amount(new[metric], metric)} of the forecast")
    if disc["items"]:
        parts.append(f"{disc['items']} discontinued item{'s' if disc['items'] != 1 else ''} "
                     f"that sold {format_amount(disc[metric], metric)} last year and sit "
                     f"outside this bridge")
    return "Assortment change: " + "; ".join(parts) + "."


def promotion_coverage_note(payload: dict) -> str | None:
    """Markdown-ready UI footnote for TY and LY any-slot promotion coverage."""
    summary = payload.get("promotion_summary") or {}
    total = summary.get("total_items")
    promoted_ty = summary.get("items_promoted_fy")
    promoted_ly = summary.get("items_promoted_ly")
    if total is None or promoted_ty is None or promoted_ly is None:
        return None
    return (
        f"Out of **{int(total)}** items in TY, **{int(promoted_ty)}** are promoted in TY "
        f"and **{int(promoted_ly)}** were promoted in LY."
    )


def freeze_check_from_row(freeze_row: dict | None) -> dict | None:
    """Turn the freeze-check SQL row into a plain verdict on the frozen-price assumption."""
    if not freeze_row:
        return None
    combos = int(freeze_row.get("item_store_combos") or 0)
    if combos <= 0:
        return None
    flat_price = int(freeze_row.get("flat_price_combos") or 0)
    flat_cost = int(freeze_row.get("flat_cost_combos") or 0)
    price_share = flat_price / combos
    cost_share = flat_cost / combos
    if price_share >= 0.999 and cost_share >= 0.999:
        verdict = "fully_frozen"
    elif price_share >= 0.95 or cost_share >= 0.95:
        verdict = "mostly_frozen"
    else:
        verdict = "not_frozen"
    return {
        "verdict": verdict,
        "frozen_price_share": price_share,
        "frozen_cost_share": cost_share,
        "item_store_combos": combos,
        "last_actual_week": str(freeze_row.get("last_actual_week") or "")[:10] or None,
        "first_future_week": str(freeze_row.get("first_future_week") or "")[:10] or None,
        "future_weeks": int(freeze_row.get("future_weeks") or 0),
    }


def elasticity_from_row(elasticity_row: dict | None) -> dict | None:
    """Weighted-OLS regular-price elasticity of units from one aggregated elasticity-SQL row.

    Slope of ln(units ratio) on ln(price ratio); the demeaning removes the shared demand trend so
    only the price response remains. Clamped to [-5.0, 0.0] to keep noisy category fits from
    producing absurd bars. None when the fit is unusable, with ``unavailable_reason`` explaining
    which check rejected it.

    A POSITIVE fitted slope is rejected rather than clamped. After demeaning it does not mean
    shoppers buy more as price rises; it means the regression is unidentified — normally
    simultaneity (prices are raised into strong demand), mix drift inside an NCRC moving the
    average regular price, or promo contamination the non-promo filter did not remove. Passing a
    positive value into the frozen-price counterfactual launders a broken fit into a parameter
    that drives the bars in the wrong direction, so it is reported as unavailable instead.
    """
    reason: str | None = None
    if not elasticity_row or not int(elasticity_row.get("matched_pairs") or 0):
        return {"price_elasticity": None, "raw_slope": None, "matched_pairs": 0,
                "unavailable_reason": "no matched item x store x week pairs in history"}
    matched = int(elasticity_row.get("matched_pairs") or 0)
    sw = float(elasticity_row.get("sw") or 0.0)
    if sw <= 0.0:
        return {"price_elasticity": None, "raw_slope": None, "matched_pairs": matched,
                "unavailable_reason": "regression weights sum to zero"}
    swx = float(elasticity_row.get("swx") or 0.0)
    swy = float(elasticity_row.get("swy") or 0.0)
    swxy = float(elasticity_row.get("swxy") or 0.0)
    swxx = float(elasticity_row.get("swxx") or 0.0)
    var_x = swxx - swx * swx / sw
    if var_x <= 1e-9:
        return {"price_elasticity": None, "raw_slope": None, "matched_pairs": matched,
                "unavailable_reason": "too little regular-price variation to identify a slope"}
    raw = (swxy - swx * swy / sw) / var_x
    if raw > 0.0:
        return {"price_elasticity": None, "raw_slope": raw, "matched_pairs": matched,
                "unavailable_reason": "fitted slope is positive, so the regression is "
                                      "unidentified (endogeneity or mix drift), not a real "
                                      "price response"}
    clamped = max(-5.0, raw)
    if clamped != raw:
        reason = "fitted slope clamped to the -5.0 floor"
    return {
        "price_elasticity": clamped,
        "raw_slope": raw,
        "matched_pairs": matched,
        "clamped": clamped != raw,
        "unavailable_reason": reason,
    }


def classify_items(selected: pd.DataFrame, *, depth_tol: float = 1e-9,
                   depth_change_tol: float = 0.005) -> pd.DataFrame:
    """Raw one-row-per-item promo/depth diagnostics using any slot incidence.

    Classes: ``new`` (FY promoted, LY not), ``stopped`` (LY promoted, FY not),
    ``deeper`` / ``shallower`` / ``unchanged`` (promoted in both; item-level average of the
    slot max(store, digital) depth compared with ``depth_change_tol``), ``never`` otherwise.
    The waterfall's exclusive displayed bucket is produced by ``classify_item_buckets``;
    this helper remains the source of depth and raw slot-count diagnostics.
    """
    df = selected.copy()
    idx = df.index
    depth_now = pd.concat(
        [_num(df.get("store_depth"), idx), _num(df.get("digital_depth"), idx)], axis=1
    ).max(axis=1)
    depth_ly = pd.concat(
        [_num(df.get("ly_store_promo_depth"), idx), _num(df.get("ly_digital_promo_depth"), idx)], axis=1
    ).max(axis=1)
    promo_now = depth_now > depth_tol
    promo_ly = depth_ly > depth_tol
    advertised_fy = _num(df.get("in_circular"), idx) > 0.0
    tmp = pd.DataFrame({
        "item_id": df["item_id"].astype(str),
        "promo_now": promo_now,
        "promo_ly": promo_ly,
        "advertised_fy": advertised_fy,
        "depth_now_promo": depth_now.where(promo_now),
        "depth_ly_promo": depth_ly.where(promo_ly),
    })
    out = (
        tmp.groupby("item_id", sort=True)
        .agg(
            promoted_now=("promo_now", "any"),
            promoted_ly=("promo_ly", "any"),
            advertised_fy=("advertised_fy", "any"),
            avg_depth_now=("depth_now_promo", "mean"),
            avg_depth_ly=("depth_ly_promo", "mean"),
            promo_slots_now=("promo_now", "sum"),
            promo_slots_ly=("promo_ly", "sum"),
        )
        .reset_index()
    )
    out["avg_depth_now"] = pd.to_numeric(out["avg_depth_now"], errors="coerce").fillna(0.0)
    out["avg_depth_ly"] = pd.to_numeric(out["avg_depth_ly"], errors="coerce").fillna(0.0)
    out["promo_slots_now"] = out["promo_slots_now"].astype(int)
    out["promo_slots_ly"] = out["promo_slots_ly"].astype(int)

    def _cls(row: pd.Series) -> str:
        if row["promoted_now"] and not row["promoted_ly"]:
            return "new"
        if row["promoted_ly"] and not row["promoted_now"]:
            return "stopped"
        if not row["promoted_now"]:
            return "never"
        delta = row["avg_depth_now"] - row["avg_depth_ly"]
        if delta > depth_change_tol:
            return "deeper"
        if delta < -depth_change_tol:
            return "shallower"
        return "unchanged"

    out["promo_class"] = out.apply(_cls, axis=1)
    return out


def classify_item_buckets(
    selected_with_baseline: pd.DataFrame,
    *,
    depth_tol: float = 1e-9,
    depth_change_tol: float = 0.005,
) -> pd.DataFrame:
    """Assign each item from any TY promotional and advertised slot incidence.

    One promoted slot makes the item promoted. One promoted-and-advertised slot makes it
    ``promoted_with_ad``; otherwise a promoted item is ``promoted_no_ad``. Items with no TY
    promotional slots are ``nonpromoted``. The same independent classification is created for LY
    so TY and LY promotional pools can be compared using identical rules.
    """
    df = selected_with_baseline.copy()
    df["item_id"] = df["item_id"].astype(str)
    idx = df.index
    depth_now = pd.concat(
        [_num(df.get("store_depth"), idx), _num(df.get("digital_depth"), idx)], axis=1
    ).max(axis=1)
    if "_ly_promo_depth_crf" in df.columns:
        depth_ly = _num(df.get("_ly_promo_depth_crf"), idx)
    else:
        depth_ly = pd.concat(
            [_num(df.get("ly_store_promo_depth"), idx),
             _num(df.get("ly_digital_promo_depth"), idx)], axis=1
        ).max(axis=1)
    promo_now = depth_now > depth_tol
    promo_ly = depth_ly > depth_tol
    advertised_fy_slot = promo_now & _num(df.get("in_circular"), idx).gt(0.0)
    advertised_ly_slot = promo_ly & _num(df.get("_advertised_ly_slot"), idx).gt(0.0)

    slot_rows = pd.DataFrame({
        "item_id": df["item_id"],
        "promo_now": promo_now,
        "promo_ly": promo_ly,
        "advertised_fy": advertised_fy_slot,
        "advertised_ly": advertised_ly_slot,
        "depth_now": depth_now.where(promo_now),
        "depth_ly": depth_ly.where(promo_ly),
    })
    items = (
        slot_rows.groupby("item_id", sort=True)
        .agg(
            promoted_now=("promo_now", "any"),
            promoted_ly=("promo_ly", "any"),
            advertised_fy=("advertised_fy", "any"),
            advertised_ly=("advertised_ly", "any"),
            avg_depth_now=("depth_now", "mean"),
            avg_depth_ly=("depth_ly", "mean"),
            promo_slots_now=("promo_now", "sum"),
            promo_slots_ly=("promo_ly", "sum"),
            ad_slots_now=("advertised_fy", "sum"),
            ad_slots_ly=("advertised_ly", "sum"),
            total_slots=("promo_now", "size"),
        )
        .reset_index()
    )
    for col in ("avg_depth_now", "avg_depth_ly"):
        items[col] = pd.to_numeric(items[col], errors="coerce").fillna(0.0)
    for col in ("promo_slots_now", "promo_slots_ly", "ad_slots_now", "ad_slots_ly",
                "total_slots"):
        items[col] = items[col].astype(int)

    items["optimizer_bucket"] = "nonpromoted"
    items.loc[items["promoted_now"], "optimizer_bucket"] = "promoted_no_ad"
    # Advertising wins when at least one TY slot is both promoted and in circular.
    items.loc[items["advertised_fy"], "optimizer_bucket"] = "promoted_with_ad"
    items["ly_optimizer_bucket"] = "nonpromoted"
    items.loc[items["promoted_ly"], "ly_optimizer_bucket"] = "promoted_no_ad"
    # Mirror the TY any-slot rule independently in LY.
    items.loc[items["advertised_ly"], "ly_optimizer_bucket"] = "promoted_with_ad"
    items["promo_slot_share_ty"] = (
        items["promo_slots_now"] / items["total_slots"].where(items["total_slots"].gt(0))
    ).fillna(0.0)
    items["ad_share_of_promo_ty"] = (
        items["ad_slots_now"] / items["promo_slots_now"].where(items["promo_slots_now"].gt(0))
    ).fillna(0.0)

    def _depth_class(row: pd.Series) -> str | None:
        if not row["promoted_now"]:
            return None
        if not row["promoted_ly"]:
            return "new"
        delta = row["avg_depth_now"] - row["avg_depth_ly"]
        if delta > depth_change_tol:
            return "deeper"
        if delta < -depth_change_tol:
            return "shallower"
        return "unchanged"

    items["promo_class"] = items.apply(_depth_class, axis=1)
    return items


_OPTIMIZER_STRATEGY_LABELS = {
    "promoted_no_ad": "promoted but no ad",
    "promoted_with_ad": "promoted with ad",
    "nonpromoted": "non-promoted",
}


def _optimizer_step_tooltip(
    strategy: str,
    *,
    metric: str,
    value: float,
    stats: dict[str, Any],
) -> tuple[str, dict[str, Any]]:
    """Dynamic merchant tooltip plus machine-readable detail for one TY optimizer bucket."""
    count = int(stats.get("items", 0))
    promo_share = stats.get("average_promo_slot_share")
    ad_share = stats.get("average_ad_share_of_promo")
    promo_share_text = (
        f" On average, {promo_share * 100:.1f}% of their TY item-slot combinations are promoted."
        if promo_share is not None else ""
    )
    amount = format_amount(value, metric)
    if strategy == "promoted_no_ad":
        depth = stats.get("depth_breakdown", {})
        text = (f"{count} items have at least one TY promotional slot and no advertised TY "
                f"promotional slots. They contribute "
                f"{amount} versus the independently classified LY promoted-no-ad pool after "
                "trend, momentum, store, and price adjustments. The LY pool contains "
                f"{int(stats.get('ly_items', 0))} items and "
                f"{int(stats.get('ly_promo_slots', 0))} promotional slots. Compared with LY, "
                "the TY items split into "
                f"{int(depth.get('new', 0))} new promotions, "
                f"{int(depth.get('deeper', 0))} deeper, "
                f"{int(depth.get('shallower', 0))} shallower, and "
                f"{int(depth.get('unchanged', 0))} unchanged-depth items.{promo_share_text}")
    elif strategy == "promoted_with_ad":
        depth = stats.get("depth_breakdown", {})
        ad_share_text = (
            f" On average, {ad_share * 100:.1f}% of their promoted TY slots are advertised."
            if ad_share is not None else ""
        )
        text = (f"{count} items have at least one TY promoted-and-advertised slot and contribute "
                f"{amount} versus the independently classified LY promoted-with-ad pool after "
                "trend, momentum, store, and price adjustments. The LY pool contains "
                f"{int(stats.get('ly_items', 0))} items and "
                f"{int(stats.get('ly_promo_slots', 0))} promotional slots. Compared with LY, "
                "the TY items split into "
                f"{int(depth.get('new', 0))} new promotions, "
                f"{int(depth.get('deeper', 0))} deeper, "
                f"{int(depth.get('shallower', 0))} shallower, and "
                f"{int(depth.get('unchanged', 0))} unchanged-depth items."
                f"{promo_share_text}{ad_share_text}")
    else:  # nonpromoted
        components = stats.get("proxy_components") or {}
        removed_items = int(components.get("promotion_removed_items", 0))
        matched_items = int(components.get("matched_nonpromo_items", 0))
        text = (
            f"{count} items have no TY promotional slots and contribute {amount}. "
            f"{removed_items} were promoted in LY and contribute the adjusted promotion-removal "
            f"estimate; {matched_items} were non-promoted in both periods and contribute their "
            "forecast variance after trend, price, and store effects."
        )
    details = {
        "items": count,
        "ly_items": int(stats.get("ly_items", 0)),
        "ly_promo_slots": int(stats.get("ly_promo_slots", 0)),
        "average_promo_slot_share": promo_share,
        "average_ad_share_of_promo": ad_share,
        "depth_breakdown": stats.get("depth_breakdown", {}),
        "proxy_components": stats.get("proxy_components"),
        "calculation": (
            "LY-adjusted promotion-removal estimate plus matched non-promo forecast variance"
            if strategy == "nonpromoted"
            else "TY promotional pool minus the independently classified LY promotional pool, "
                 "after removing category trend, trend momentum, store-count, realized "
                 "price/cost, and frozen price/cost effects from the LY pool"
        ),
    }
    return text, details


def _to_native(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _to_native(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_native(v) for v in value]
    try:
        if value is not None and pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if hasattr(value, "item") and not isinstance(value, str):
        try:
            return value.item()
        except (ValueError, AttributeError):
            pass
    if isinstance(value, (pd.Timestamp,)):
        return str(value)
    return value


def compute_waterfall(
    selected: pd.DataFrame,
    baseline: pd.DataFrame | None = None,
    price_effects: pd.DataFrame | None = None,
    trend_row: dict | None = None,
    drift_row: dict | None = None,
    elasticity_row: dict | None = None,
    *,
    momentum_row: dict | None = None,
    objective: str = "sales",
    depth_tol: float = 1e-9,
    depth_change_tol: float = 0.005,
    drift_overrides: dict | None = None,
    freeze_row: dict | None = None,
    assortment: pd.DataFrame | None = None,
    excluded_ly_context: pd.DataFrame | None = None,
    store_effects: pd.DataFrame | None = None,
    ly_circular: pd.DataFrame | None = None,
) -> dict:
    """Build the full bridge payload for one selected objective plan.

    ``selected``: one row per selected slot (item_id, price_area_cd, week_start_date, depths,
    LY depths, optimizer_units/revenue/agp, ly_units/ly_sales/ly_agp).
    ``baseline``: per-slot no-promo candidate forecast (base_units/base_sales/base_agp).
    ``price_effects``: per item x price-area x week ly_units / d_price_sales / d_cost_agp
    (optionally ly_units_x_fut_price / ly_units_x_fut_deadnet for the frozen-gap bars).
    ``trend_row``: single aggregated row from the trend SQL (dict) or None.
    ``momentum_row``: projected post-freeze Q4 totals from the trend-momentum SQL or None.
    ``drift_row``: single aggregated row from the price-drift SQL (dict) or None.
    ``elasticity_row``: single aggregated row from the price-elasticity SQL (dict) or None.
    ``excluded_ly_context``: one-row excluded-item LY sales result. It is displayed as a
    context-only cap above the sales LY bar and never enters the bridge arithmetic.
    ``store_effects``: item x price-area future/LY active-store counts and additive sales, units,
    and AGP effects from holding LY performance per store constant. Legacy per-slot inputs remain
    supported.

    The frozen price/cost impact bars compare the frozen forecast world with the realistic world
    where price and cost kept drifting past ``freeze_week`` at their historical rates and demand
    responded per the measured elasticity. Per forecast week w with expected-but-not-taken price
    move g_p(w) = price drift x gap promo-weeks / 52 (and g_c(w) for cost), elasticity e:

      units gap = sum U x (1 - (1 + e g_p))              frozen units minus BAU units
      sales gap = sum U P x (1 - (1 + g_p)(1 + e g_p))  frozen sales minus BAU sales
      price AGP gap = frozen margin - realistic margin

    The frozen-cost gap uses the same frozen-outcome-minus-BAU convention.

    With no measurable elasticity (e = 0) these collapse to the mechanical drift adjustment.

    ``drift_overrides``: optional merchant-supplied {price_drift_annual, cost_drift_annual,
    freeze_week} that replace the estimated drift (e.g. eggs expected +8%/yr, not the historical
    average). Non-None values win over the estimate; the freeze week falls back to the estimated
    one when not overridden.
    """
    obj_label = normalize_objective(objective)
    df = selected.copy()
    if df.empty:
        return {"objective": obj_label, "error": "no selected-plan rows in scope",
                "metrics": {}, "promotion_summary": {}, "strategy_contribution": [],
                "diagnostics": {"selected_slots": 0}}
    for key in SLOT_KEYS:
        df[key] = df[key].astype(str)
    idx = df.index
    depth_now = pd.concat(
        [_num(df.get("store_depth"), idx), _num(df.get("digital_depth"), idx)], axis=1
    ).max(axis=1)
    depth_ly = pd.concat(
        [_num(df.get("ly_store_promo_depth"), idx), _num(df.get("ly_digital_promo_depth"), idx)], axis=1
    ).max(axis=1)
    df["_promo_now"] = depth_now > depth_tol
    df["_promo_ly"] = depth_ly > depth_tol

    # Per-slot no-promo baseline forecasts.
    base_cols = ["base_units", "base_sales", "base_agp"]
    if baseline is not None and not baseline.empty:
        base = baseline.copy()
        for key in SLOT_KEYS:
            base[key] = base[key].astype(str)
        base = base.groupby(SLOT_KEYS, as_index=False)[base_cols].mean()
        df = df.merge(base, on=SLOT_KEYS, how="left")
    else:
        for col in base_cols:
            df[col] = float("nan")

    # LY promotion depth and circular incidence are matched from CRF at item x price-area x
    # aligned-future-week. Retain compatibility with older inputs that contain only advertised_ly;
    # when the CRF promotion fields are present, they are authoritative over detail-table LY depth.
    if "advertised_ly" in df.columns:
        df["_advertised_ly_slot"] = _num(df.get("advertised_ly"), df.index)
    else:
        df["_advertised_ly_slot"] = 0.0
    if ly_circular is not None and not ly_circular.empty:
        ly_ad = ly_circular.copy()
        ly_ad["item_id"] = ly_ad["item_id"].astype(str)
        ly_keys = [key for key in SLOT_KEYS if key in ly_ad.columns]
        if "item_id" not in ly_keys:
            ly_keys.insert(0, "item_id")
        for key in ly_keys:
            ly_ad[key] = ly_ad[key].astype(str)
        ly_ad["_ly_circular_joined"] = _num(ly_ad.get("advertised_ly"), ly_ad.index)
        join_value_cols = ["_ly_circular_joined"]
        if "promoted_ly" in ly_ad.columns:
            ly_ad["_ly_promoted_joined"] = _num(ly_ad.get("promoted_ly"), ly_ad.index)
            join_value_cols.append("_ly_promoted_joined")
        if "ly_promo_depth" in ly_ad.columns:
            ly_ad["_ly_depth_joined"] = _num(ly_ad.get("ly_promo_depth"), ly_ad.index)
            join_value_cols.append("_ly_depth_joined")
        ly_ad = ly_ad.groupby(ly_keys, as_index=False)[join_value_cols].max()
        df = df.merge(ly_ad, on=ly_keys, how="left")
        df["_advertised_ly_slot"] = _num(df.get("_ly_circular_joined"), df.index)
        if "_ly_promoted_joined" in df.columns:
            df["_promo_ly"] = _num(df.get("_ly_promoted_joined"), df.index).gt(0.0)
        if "_ly_depth_joined" in df.columns:
            df["_ly_promo_depth_crf"] = _num(df.get("_ly_depth_joined"), df.index)
            depth_ly = df["_ly_promo_depth_crf"]
            df["_promo_ly"] = depth_ly.gt(depth_tol)
        df.drop(columns=[
            col for col in ("_ly_circular_joined", "_ly_promoted_joined", "_ly_depth_joined")
            if col in df.columns
        ], inplace=True)
    df["_advertised_ly_slot"] = (
        df["_promo_ly"] & _num(df.get("_advertised_ly_slot"), df.index).gt(0.0)
    )

    items = classify_item_buckets(
        df, depth_tol=depth_tol, depth_change_tol=depth_change_tol
    )
    item_cols = [
        "item_id", "promo_class", "optimizer_bucket", "ly_optimizer_bucket",
        "promoted_now", "promoted_ly",
        "advertised_fy", "advertised_ly", "promo_slot_share_ty", "ad_share_of_promo_ty",
    ]
    df = df.merge(items[item_cols], on="item_id", how="left")
    df["_advertised_fy_slot"] = df["_promo_now"] & _num(
        df.get("in_circular"), df.index
    ).gt(0.0)

    # Change caused by the future active-store footprint versus the LY footprint. The current SQL
    # returns one item x price-area ratio; apply it to each selected slot's LY values so the period
    # total is not repeated once per week. Retain support for legacy per-slot store-effect tables.
    store_cols = ["future_store_count", "ly_store_count", "store_count_change",
                  "d_store_sales", "d_store_units", "d_store_agp"]
    if store_effects is not None and not store_effects.empty:
        se = store_effects.copy()
        store_keys = ["item_id", "price_area_cd"]
        for key in store_keys:
            se[key] = se[key].astype(str)
        for col in store_cols:
            se[col] = pd.to_numeric(se.get(col), errors="coerce")
        if "week_start_date" in se.columns:
            se["week_start_date"] = se["week_start_date"].astype(str)
            se["_store_effect_matched"] = (
                se["future_store_count"].notna() & se["ly_store_count"].gt(0)
            )
            se = se.groupby(SLOT_KEYS, as_index=False).agg({
                **{col: "mean" for col in store_cols},
                "_store_effect_matched": "max",
            })
            df = df.merge(se, on=SLOT_KEYS, how="left")
        else:
            count_cols = ["future_store_count", "ly_store_count", "store_count_change"]
            se = se.groupby(store_keys, as_index=False)[count_cols].mean()
            df = df.merge(se, on=store_keys, how="left")
            df["_store_effect_matched"] = (
                df["future_store_count"].notna() & df["ly_store_count"].gt(0)
            )
            store_ratio = (
                df["future_store_count"] / df["ly_store_count"]
            ).where(df["_store_effect_matched"])
            for metric in METRICS:
                ly_col = _METRIC_COLS[metric][1]
                df[f"d_store_{metric}"] = (
                    _num(df.get(ly_col), df.index) * (store_ratio - 1.0)
                )
    else:
        for col in store_cols:
            df[col] = float("nan")
        df["_store_effect_matched"] = False
    df["_store_effect_matched"] = df["_store_effect_matched"].fillna(False).astype(bool)
    for col in ("d_store_sales", "d_store_units", "d_store_agp"):
        df[col] = _num(df[col], df.index)
    store_effect_totals = {
        metric: float(df[f"d_store_{metric}"].sum()) for metric in METRICS
    }

    # Per item x price-area x week realized (LY -> freeze) price/cost effects.
    raw_cols = ["d_price_sales", "d_cost_agp", "ly_units",
                "ly_units_x_fut_price", "ly_units_x_fut_deadnet"]
    price_cols = ["realized_price_sales", "realized_price_units", "realized_price_agp",
                  "realized_cost_agp", "frozen_price_gap_sales",
                  "frozen_price_gap_units", "frozen_price_gap_agp",
                  "frozen_cost_gap_agp"]
    price_gap_sales = 0.0
    price_gap_units = 0.0
    price_gap_agp = 0.0
    cost_gap_agp = 0.0
    price_revaluation_sales = 0.0
    drift = drift_from_row(drift_row)
    if drift_overrides and any(v is not None for v in drift_overrides.values()):
        base = drift or {"price_drift_annual": 0.0, "cost_drift_annual": 0.0,
                         "freeze_week": None, "matched_pairs": 0}
        drift = {**base, **{k: v for k, v in drift_overrides.items() if v is not None}}
        drift["source"] = "override"
        if not drift.get("freeze_week"):
            drift = None  # no freeze point to measure the gap from
    elif drift is not None:
        drift["source"] = "estimated"
    elasticity = elasticity_from_row(elasticity_row)
    # No measurable elasticity is NOT a neutral fallback. At e = 0 the frozen-price bars reduce
    # to -U*P*g, which is strictly negative under positive price drift, and the units bar
    # disappears entirely. ``elasticity_available`` is surfaced in diagnostics so the UI can say
    # the bar rests on an assumption rather than a measurement.
    elasticity_value = (elasticity or {}).get("price_elasticity")
    e = elasticity_value if elasticity_value is not None else 0.0
    if price_effects is not None and not price_effects.empty:
        pe = price_effects.copy()
        for key in SLOT_KEYS:
            pe[key] = pe[key].astype(str)
        for col in raw_cols:
            pe[col] = _num(pe.get(col), pe.index)

        # Realized LY -> freeze price/cost change, WITH the demand response. p_ly / c_ly are the
        # LY-unit-weighted LY price and cost levels; r_p is the realized price ratio; uf is the
        # units factor the elasticity implies. With e = 0 this collapses to the pure mechanical
        # revaluation (LY units x price change), which stays available as a diagnostic.
        p_ly = pe["ly_units_x_fut_price"] - pe["d_price_sales"]
        c_ly = pe["ly_units_x_fut_deadnet"] + pe["d_cost_agp"]
        r_p = (pe["d_price_sales"] / p_ly.where(p_ly > 0)).fillna(0.0)
        uf = 1.0 + e * r_p
        pe["realized_price_sales"] = uf * (p_ly + pe["d_price_sales"]) - p_ly
        pe["realized_price_units"] = pe["ly_units"] * e * r_p
        pe["realized_price_agp"] = uf * (p_ly + pe["d_price_sales"] - c_ly) - (p_ly - c_ly)
        pe["realized_cost_agp"] = uf * pe["d_cost_agp"]
        for col in ("frozen_price_gap_sales", "frozen_price_gap_units",
                    "frozen_price_gap_agp", "frozen_cost_gap_agp"):
            pe[col] = 0.0
        price_revaluation_sales = float(pe["d_price_sales"].sum())
        # Frozen-price impact is presented as the frozen-price outcome relative to BAU:
        # frozen outcome minus continued-drift outcome. The gap uses 7-day promo weeks,
        # with annual drift prorated per 52 weeks and demand responding at historical elasticity.
        if drift is not None:
            gap_weeks = (
                (pd.to_datetime(pe["week_start_date"]) - pd.to_datetime(drift["freeze_week"]))
                .dt.days.clip(lower=0) / 7.0
            )
            g_p = drift["price_drift_annual"] * gap_weeks / 52.0
            g_c = drift["cost_drift_annual"] * gap_weeks / 52.0
            units_w = pe["ly_units"]
            up = pe["ly_units_x_fut_price"]
            uc = pe["ly_units_x_fut_deadnet"]
            realistic_units_factor = 1.0 + e * g_p
            pe["frozen_price_gap_units"] = units_w * (1.0 - realistic_units_factor)
            pe["frozen_price_gap_sales"] = (
                up * (1.0 - (1.0 + g_p) * realistic_units_factor)
            )
            # Frozen-cost AGP minus BAU continued-cost-drift AGP. Positive expected cost drift
            # therefore produces a positive benefit from keeping forecast costs frozen.
            pe["frozen_cost_gap_agp"] = realistic_units_factor * uc * g_c
            pe["frozen_price_gap_agp"] = (
                (up - uc) - realistic_units_factor * (up * (1.0 + g_p) - uc)
            )
            price_gap_units = float(pe["frozen_price_gap_units"].sum())
            price_gap_sales = float(pe["frozen_price_gap_sales"].sum())
            cost_gap_agp = float(pe["frozen_cost_gap_agp"].sum())
            price_gap_agp = float(pe["frozen_price_gap_agp"].sum())
        pe = pe.groupby(SLOT_KEYS, as_index=False)[price_cols].sum()
        realized_price = {
            "sales": float(pe["realized_price_sales"].sum()),
            "units": float(pe["realized_price_units"].sum()),
            "agp": float(pe["realized_price_agp"].sum()),
        }
        realized_cost_agp = float(pe["realized_cost_agp"].sum())
        df = df.merge(pe, on=SLOT_KEYS, how="left")
    else:
        realized_price = {"sales": 0.0, "units": 0.0, "agp": 0.0}
        realized_cost_agp = 0.0
        for col in price_cols:
            df[col] = 0.0
    for col in price_cols:
        df[col] = _num(df[col], df.index)

    trend_ratios: dict[str, float | None] = {}
    trend_diagnostics: dict[str, dict[str, Any]] = {}
    momentum_ratios: dict[str, float | None] = {}
    momentum_diagnostics: dict[str, dict[str, Any]] = {}
    for trend_metric in METRICS:
        trend_ratio, metric_diag = trend_ratio_from_row(trend_row, trend_metric)
        trend_ratios[trend_metric] = trend_ratio
        trend_diagnostics[trend_metric] = metric_diag
        momentum_ratio, momentum_diag = momentum_ratio_from_row(
            momentum_row, trend_metric
        )
        momentum_ratios[trend_metric] = momentum_ratio
        momentum_diagnostics[trend_metric] = momentum_diag

    excluded_ly_summary = summarize_excluded_ly_context(excluded_ly_context)

    matched_nonpromo = (~df["_promo_now"]) & (~df["_promo_ly"])
    removed_slot_mask = (
        (~df["_promo_now"])
        & df["_promo_ly"]
        & df["optimizer_bucket"].eq("nonpromoted")
        & df["promoted_ly"]
    )
    strategy_order = ["promoted_no_ad", "promoted_with_ad", "nonpromoted"]
    bucket_counts = items["optimizer_bucket"].value_counts().to_dict()
    ly_bucket_counts = items["ly_optimizer_bucket"].value_counts().to_dict()
    slot_bucket = df.groupby("optimizer_bucket")["_promo_now"].sum().to_dict()
    ly_slot_bucket = df.groupby("ly_optimizer_bucket")["_promo_ly"].sum().to_dict()
    optimizer_display_labels = {
        bucket: f"{int(bucket_counts.get(bucket, 0))} {_OPTIMIZER_STRATEGY_LABELS[bucket]}"
        for bucket in strategy_order
    }
    strategy_stats: dict[str, dict[str, Any]] = {}
    for bucket in strategy_order:
        group = items[items["optimizer_bucket"] == bucket]
        depth = group["promo_class"].value_counts().to_dict()
        strategy_stats[bucket] = {
            "items": int(group.shape[0]),
            "ly_items": int(ly_bucket_counts.get(bucket, 0)),
            "ly_promo_slots": int(ly_slot_bucket.get(bucket, 0)),
            "average_promo_slot_share": (
                float(group["promo_slot_share_ty"].mean()) if not group.empty else None
            ),
            "average_ad_share_of_promo": (
                float(group["ad_share_of_promo_ty"].mean()) if not group.empty else None
            ),
            "depth_breakdown": {
                name: int(depth.get(name, 0))
                for name in ("new", "deeper", "shallower", "unchanged")
            },
        }

    metrics_payload: dict[str, Any] = {}
    strategy_rows: dict[str, dict[str, Any]] = {
        bucket: {"strategy": bucket} for bucket in strategy_order
    }
    removed_proxy_diagnostics: dict[str, dict[str, Any]] = {}
    promoted_ly_adjustment_diagnostics: dict[str, dict[str, Any]] = {}
    for metric in METRICS:
        ratio = trend_ratios[metric]
        trend_factor = (ratio - 1.0) if ratio is not None else 0.0
        fy_col, ly_col, _ = _METRIC_COLS[metric]
        fy = _num(df.get(fy_col), df.index)
        ly = _num(df.get(ly_col), df.index)
        ly_total = float(ly.sum())
        fy_total = float(fy.sum())

        trend_total = trend_factor * ly_total
        trend_nonpromo_share = trend_factor * float(ly[matched_nonpromo].sum())
        momentum_ratio = momentum_ratios[metric]
        momentum_factor = (
            momentum_ratio - (ratio if ratio is not None else 1.0)
            if momentum_ratio is not None else 0.0
        )
        momentum_total = (
            ly_total * momentum_factor
            if momentum_ratio is not None else 0.0
        )
        momentum_nonpromo_share = (
            momentum_total * float(ly[matched_nonpromo].sum()) / ly_total
            if ly_total else 0.0
        )
        store_total = store_effect_totals[metric]
        store_nonpromo_share = float(
            df.loc[matched_nonpromo, f"d_store_{metric}"].sum()
        )

        realized_price_metric = realized_price[metric]
        if metric == "sales":
            price_total = realized_price_metric
            gap_price_metric = price_gap_sales
            gap_total = price_gap_sales
            price_nonpromo_share = float(df.loc[matched_nonpromo, "realized_price_sales"].sum())
            price_removed_share = float(
                df.loc[removed_slot_mask, "realized_price_sales"].sum()
            )
            price_slot_effect = _num(df.get("realized_price_sales"), df.index)
            gap_slot_effect = _num(df.get("frozen_price_gap_sales"), df.index)
        elif metric == "agp":
            price_total = realized_price_metric + realized_cost_agp
            gap_price_metric = price_gap_agp
            gap_total = price_gap_agp + cost_gap_agp
            price_nonpromo_share = float(
                (df.loc[matched_nonpromo, "realized_price_agp"]
                 + df.loc[matched_nonpromo, "realized_cost_agp"]).sum()
            )
            price_removed_share = float(
                (df.loc[removed_slot_mask, "realized_price_agp"]
                 + df.loc[removed_slot_mask, "realized_cost_agp"]).sum()
            )
            price_slot_effect = (
                _num(df.get("realized_price_agp"), df.index)
                + _num(df.get("realized_cost_agp"), df.index)
            )
            gap_slot_effect = (
                _num(df.get("frozen_price_gap_agp"), df.index)
                + _num(df.get("frozen_cost_gap_agp"), df.index)
            )
        else:
            price_total = realized_price_metric
            gap_price_metric = price_gap_units
            gap_total = price_gap_units
            price_nonpromo_share = float(df.loc[matched_nonpromo, "realized_price_units"].sum())
            price_removed_share = float(
                df.loc[removed_slot_mask, "realized_price_units"].sum()
            )
            price_slot_effect = _num(df.get("realized_price_units"), df.index)
            gap_slot_effect = _num(df.get("frozen_price_gap_units"), df.index)

        # LY-based proxy for items with no TY promo slots but at least one LY promo slot. The raw
        # FY-no-promo minus LY-promo movement includes trend, realized price/cost, and store
        # changes that already have their own bars, so remove those allocated shares here.
        removed_raw_change = float((fy - ly)[removed_slot_mask].sum())
        removed_trend_share = trend_factor * float(ly[removed_slot_mask].sum())
        removed_momentum_share = (
            momentum_total * float(ly[removed_slot_mask].sum()) / ly_total
            if ly_total else 0.0
        )
        removed_store_share = float(
            df.loc[removed_slot_mask, f"d_store_{metric}"].sum()
        )
        removed_effect = (
            removed_raw_change
            - removed_trend_share
            - removed_momentum_share
            - price_removed_share
            - removed_store_share
        )
        removed_proxy_diagnostics[metric] = {
            "source": "ly_adjusted_proxy",
            "slots": int(removed_slot_mask.sum()),
            "raw_fy_minus_ly": removed_raw_change,
            "trend_already_attributed": removed_trend_share,
            "momentum_already_attributed": removed_momentum_share,
            "realized_price_cost_already_attributed": price_removed_share,
            "store_already_attributed": removed_store_share,
            "estimated_promotion_removed_effect": removed_effect,
        }

        # Compare independently classified TY and LY promotional pools using the same any-slot
        # item rule. A TY advertised item contributes all of its TY promo slots to the with-ad TY
        # pool; an LY advertised item independently contributes all of its LY promo slots to the
        # with-ad LY pool. The no-ad pools follow the same symmetric rule. Prior-bar adjustments
        # are removed from the LY pool against which TY is compared.
        trend_slot_effect = ly * trend_factor
        momentum_slot_effect = ly * momentum_factor
        store_slot_effect = _num(df.get(f"d_store_{metric}"), df.index)
        opt_by_bucket = {bucket: 0.0 for bucket in strategy_order}
        promoted_ly_adjustment_diagnostics[metric] = {}
        for bucket in ("promoted_no_ad", "promoted_with_ad"):
            ty_bucket_mask = df["_promo_now"] & df["optimizer_bucket"].eq(bucket)
            ly_bucket_mask = df["_promo_ly"] & df["ly_optimizer_bucket"].eq(bucket)
            ty_pool_total = float(fy[ty_bucket_mask].sum())
            ly_pool_total = float(ly[ly_bucket_mask].sum())
            raw_pool_change = ty_pool_total - ly_pool_total
            trend_share = float(trend_slot_effect[ly_bucket_mask].sum())
            momentum_share = float(momentum_slot_effect[ly_bucket_mask].sum())
            store_share = float(store_slot_effect[ly_bucket_mask].sum())
            price_share = float(price_slot_effect[ly_bucket_mask].sum())
            gap_share = float(gap_slot_effect[ly_bucket_mask].sum())
            opt_by_bucket[bucket] = (
                raw_pool_change - trend_share - momentum_share - store_share
                - price_share - gap_share
            )
            promoted_ly_adjustment_diagnostics[metric][bucket] = {
                "comparison": "symmetric_ty_ly_promotional_pools",
                "ty_items": int(bucket_counts.get(bucket, 0)),
                "ly_items": int(ly_bucket_counts.get(bucket, 0)),
                "ty_promo_slots": int(ty_bucket_mask.sum()),
                "ly_promo_slots": int(ly_bucket_mask.sum()),
                "ty_pool_total": ty_pool_total,
                "ly_pool_total": ly_pool_total,
                "raw_fy_minus_ly": raw_pool_change,
                "trend_already_attributed": trend_share,
                "momentum_already_attributed": momentum_share,
                "store_already_attributed": store_share,
                "realized_price_cost_already_attributed": price_share,
                "frozen_price_cost_already_attributed": gap_share,
                "adjusted_optimizer_effect": opt_by_bucket[bucket],
            }
        raw_nonpromo_var = float((fy - ly)[matched_nonpromo].sum())
        nonpromo_var = (
            raw_nonpromo_var - trend_nonpromo_share - momentum_nonpromo_share
            - price_nonpromo_share - store_nonpromo_share
        )

        # The non-promoted TY bucket presents all no-promotion item movement in one place:
        # promotion removal for items promoted in LY plus adjusted forecast variance for items
        # non-promoted in both periods. There is no separate matched non-promo waterfall bar.
        opt_by_bucket["nonpromoted"] += removed_effect + nonpromo_var
        opt_total = sum(opt_by_bucket.values())

        explained = (
            trend_total + momentum_total + store_total + price_total + gap_total + opt_total
        )
        residual = fy_total - ly_total - explained

        ly_step = {"key": "ly_actual", "label": "LY actual", "value": ly_total}
        metric_ly_context = None
        if metric == "sales" and excluded_ly_summary:
            metric_ly_context = {
                **excluded_ly_summary,
                "in_scope_ly_sales": ly_total,
                "full_category_ly_sales": (
                    ly_total + excluded_ly_summary["excluded_ly_sales"]
                ),
                "enters_waterfall": False,
            }
            ly_step["context_cap"] = metric_ly_context

        steps = [ly_step,
                 {"key": "category_trend", "label": "Underlying category trend", "value": trend_total},
                 {"key": "trend_momentum", "label": "Post-freeze trend momentum",
                  "display_label": "Trend momentum", "value": momentum_total},
                 {"key": "store_footprint", "label": "Store-footprint change",
                  "display_label": "Store-count impact", "value": store_total},
                 {"key": "mechanical_price", "label": "Realized regular-price change (LY to freeze)",
                  "display_label": "Realized price change",
                  "value": realized_price_metric}]
        steps.append({"key": "frozen_price_gap",
                      "label": "Frozen-price impact (missing drift x demand response)",
                      "display_label": "Frozen-price impact",
                      "value": gap_price_metric})
        if metric == "agp":
            steps.append({"key": "frozen_cost", "label": "Realized cost & allowance change (LY to freeze)",
                          "display_label": "Realized cost change",
                          "value": realized_cost_agp})
            steps.append({"key": "frozen_cost_gap",
                          "label": "Frozen-cost impact (frozen cost minus BAU drift)",
                          "display_label": "Frozen-cost impact",
                          "value": cost_gap_agp})
        for bucket in strategy_order:
            tooltip_stats = dict(strategy_stats[bucket])
            if bucket == "nonpromoted":
                tooltip_stats["proxy_components"] = {
                    "promotion_removed_items": int(
                        ((~items["promoted_now"]) & items["promoted_ly"]).sum()
                    ),
                    "matched_nonpromo_items": int(
                        ((~items["promoted_now"]) & (~items["promoted_ly"])).sum()
                    ),
                    "estimated_promotion_removed_effect": removed_effect,
                    "matched_nonpromo_forecast_variance": nonpromo_var,
                    "combined_nonpromoted_effect": opt_by_bucket[bucket],
                }
            tooltip, tooltip_data = _optimizer_step_tooltip(
                bucket, metric=metric, value=opt_by_bucket[bucket], stats=tooltip_stats
            )
            steps.append({
                "key": f"optimizer_{bucket}",
                "label": f"Optimizer: {_OPTIMIZER_STRATEGY_LABELS[bucket]}",
                "display_label": optimizer_display_labels[bucket],
                "items": int(bucket_counts.get(bucket, 0)),
                "ly_items": int(ly_bucket_counts.get(bucket, 0)),
                "promo_slots": int(slot_bucket.get(bucket, 0)),
                "ly_promo_slots": int(ly_slot_bucket.get(bucket, 0)),
                "context_only": False,
                "estimated": True,
                "tooltip": tooltip,
                "tooltip_data": tooltip_data,
                "value": opt_by_bucket[bucket],
            })
        steps.append({"key": "residual", "label": "Remaining forecast residual", "value": residual})
        steps.append({"key": "fy_forecast", "label": "FY forecast", "value": fy_total})

        running = 0.0
        for step in steps:
            step.setdefault("display_label", step["label"])
            if step["key"] in ("ly_actual", "fy_forecast"):
                running = step["value"] if step["key"] == "ly_actual" else running
                step["running"] = step["value"] if step["key"] == "ly_actual" else fy_total
            else:
                running += step["value"]
                step["running"] = running

        contributors = {bucket: 0.0 for bucket in CONTRIBUTOR_ORDER}
        for step in steps:
            bucket = _CONTRIBUTOR_BUCKETS.get(step["key"])
            if bucket:
                contributors[bucket] += step["value"]

        # The shaded "Optimizer contribution" band: total plus the running-value span the UI
        # should shade (from the base of the first optimizer bar to the top of the last).
        opt_steps = [s for s in steps if s["key"].startswith("optimizer_")]
        optimizer_band = {
            "label": "Optimizer contribution",
            "total": opt_total,
            "from_running": opt_steps[0]["running"] - opt_steps[0]["value"],
            "to_running": opt_steps[-1]["running"],
            "step_keys": [s["key"] for s in opt_steps],
        }

        # Executive framing: what the year would have done WITHOUT the optimizer (organic demand
        # plus the price/cost the merchants froze), what the plan grossly identifies, and what
        # survives forecast reconciliation as net incremental.
        total_change = fy_total - ly_total
        without_optimizer = contributors["organic_demand"] + contributors["pricing_and_cost"]
        executive = {
            "without_optimizer": without_optimizer,
            "without_optimizer_pct": (without_optimizer / ly_total) if ly_total else None,
            "optimizer_gross": contributors["optimization"],
            "reconciliation": contributors["model_variance"],
            "net_incremental": total_change - without_optimizer,
            "net_incremental_pct_points": ((total_change - without_optimizer) / ly_total)
            if ly_total else None,
            "total_change": total_change,
            "total_change_pct": (total_change / ly_total) if ly_total else None,
        }

        metrics_payload[metric] = {
            "ly_actual": ly_total,
            "fy_forecast": fy_total,
            "change": total_change,
            "change_pct": (total_change / ly_total) if ly_total else None,
            "optimizer_total": opt_total,
            "ly_actual_context": metric_ly_context,
            "promotion_removed_impact": {
                "estimated_effect": removed_effect,
                "matched_nonpromo_forecast_variance": nonpromo_var,
                "combined_nonpromoted_effect": opt_by_bucket["nonpromoted"],
                "optimizer_total_without_proxy": opt_total - removed_effect,
                "optimizer_total_with_proxy": opt_total,
                "residual_without_proxy": residual + removed_effect,
                "residual_with_proxy": residual,
            },
            "optimizer_band": optimizer_band,
            "contributors": contributors,
            "executive": executive,
            "steps": steps,
        }
        for bucket in strategy_order:
            strategy_rows[bucket][metric] = opt_by_bucket[bucket]

    # Promotion summary tables.
    promoted_now_items = items[items["promoted_now"]]
    promoted_ly_items = items[items["promoted_ly"]]
    bucket_depths = items.groupby("optimizer_bucket")[["avg_depth_ly", "avg_depth_now"]].mean()
    for bucket in strategy_order:
        row = strategy_rows[bucket]
        row["items"] = int(bucket_counts.get(bucket, 0))
        row["ly_items"] = int(ly_bucket_counts.get(bucket, 0))
        row["promo_slots"] = int(slot_bucket.get(bucket, 0))
        row["ly_promo_slots"] = int(ly_slot_bucket.get(bucket, 0))
        in_depths = bucket in bucket_depths.index
        row["avg_depth_ly"] = (
            float(bucket_depths.loc[bucket, "avg_depth_ly"]) if in_depths else None
        )
        row["avg_depth_fy"] = (
            float(bucket_depths.loc[bucket, "avg_depth_now"]) if in_depths else None
        )
        row.update(strategy_stats[bucket])

    promotion_summary = {
        "total_items": int(items.shape[0]),
        "items_promoted_ly": int(items["promoted_ly"].sum()),
        "items_promoted_fy": int(items["promoted_now"].sum()),
        "items_deeper": int((items["promo_class"] == "deeper").sum()),
        "items_shallower": int((items["promo_class"] == "shallower").sum()),
        "items_unchanged_depth": int((items["promo_class"] == "unchanged").sum()),
        "promoted_no_ad_items": int(bucket_counts.get("promoted_no_ad", 0)),
        "promoted_with_ad_items": int(bucket_counts.get("promoted_with_ad", 0)),
        "nonpromoted_items": int(bucket_counts.get("nonpromoted", 0)),
        "promoted_no_ad_depth_breakdown": strategy_stats["promoted_no_ad"]["depth_breakdown"],
        "promoted_with_ad_depth_breakdown": strategy_stats["promoted_with_ad"][
            "depth_breakdown"
        ],
        "optimizer_bucket_counts": {
            bucket: int(bucket_counts.get(bucket, 0)) for bucket in strategy_order
        },
        "optimizer_bucket_counts_ly": {
            bucket: int(ly_bucket_counts.get(bucket, 0)) for bucket in strategy_order
        },
        "total_slots": int(df.shape[0]),
        "promo_slots_ly": int(df["_promo_ly"].sum()),
        "promo_slots_fy": int(df["_promo_now"].sum()),
        "promo_items_advertised_fy": int(items["advertised_fy"].sum()),
        "promo_rate_ly": float(df["_promo_ly"].mean()),
        "promo_rate_fy": float(df["_promo_now"].mean()),
        "item_promo_share_ly": float(items["promoted_ly"].mean()),
        "item_promo_share_fy": float(items["promoted_now"].mean()),
        "avg_item_depth_ly": float(promoted_ly_items["avg_depth_ly"].mean()) if not promoted_ly_items.empty else None,
        "avg_item_depth_fy": float(promoted_now_items["avg_depth_now"].mean()) if not promoted_now_items.empty else None,
        "avg_slot_depth_ly": float(depth_ly[df["_promo_ly"]].mean()) if bool(df["_promo_ly"].any()) else None,
        "avg_slot_depth_fy": float(depth_now[df["_promo_now"]].mean()) if bool(df["_promo_now"].any()) else None,
    }

    diagnostics = {
        "selected_slots": int(df.shape[0]),
        "matched_nonpromo_slots": int(matched_nonpromo.sum()),
        "promo_slots_missing_baseline": int((df["_promo_now"] & pd.to_numeric(
            df["base_sales"], errors="coerce").isna()).sum()),
        "trend_sales_ratio": trend_ratios["sales"],
        "trend_units_ratio": trend_ratios["units"],
        "trend_agp_ratio": trend_ratios["agp"],
        "trend_ratios": trend_ratios,
        "trend": {
            **trend_diagnostics["units"],
            "metric_ratios": trend_ratios,
        },
        "trend_momentum": {
            **momentum_diagnostics["units"],
            "projected_to_ly_q4_ratios": momentum_ratios,
        },
        "realized_price_effect": realized_price,
        "realized_cost_effect_agp": realized_cost_agp,
        # Pure revaluation (LY units x price change, no demand response) — reference only.
        "price_revaluation_sales": price_revaluation_sales,
        "frozen_price_gap_sales": price_gap_sales,
        "frozen_price_gap_units": price_gap_units,
        "frozen_price_gap_agp": price_gap_agp,
        "frozen_cost_gap_agp": cost_gap_agp,
        "price_drift": drift,
        "price_elasticity": elasticity,
        "elasticity_available": elasticity_value is not None,
        "frozen_price_assumes_zero_elasticity": elasticity_value is None,
        "freeze_check": freeze_check_from_row(freeze_row),
        "store_footprint_effect": store_effect_totals,
        "store_footprint_matched_slots": int(df["_store_effect_matched"].sum()),
        "store_footprint_missing_slots": int((~df["_store_effect_matched"]).sum()),
        "promoted_with_ad_items": int(bucket_counts.get("promoted_with_ad", 0)),
        "promoted_with_ad_slots": int(
            slot_bucket.get("promoted_with_ad", 0)
        ),
        "advertised_promo_slots_fy": int(df["_advertised_fy_slot"].sum()),
        "advertised_promo_slots_ly": int(df["_advertised_ly_slot"].sum()),
        "promotion_removed_proxy": removed_proxy_diagnostics,
        "promoted_ly_adjustment": promoted_ly_adjustment_diagnostics,
        "average_item_promo_slot_share_ty": float(items["promo_slot_share_ty"].mean()),
        "average_ad_share_of_promo_ty": float(
            items.loc[items["promoted_now"], "ad_share_of_promo_ty"].mean()
        ) if bool(items["promoted_now"].any()) else None,
        "week_start_min": str(df["week_start_date"].min()),
        "week_start_max": str(df["week_start_date"].max()),
    }

    scope_label = None
    if "category" in df.columns:
        cats = df["category"].dropna().astype(str).unique()
        if len(cats) == 1:
            scope_label = cats[0]
        elif len(cats) > 1:
            scope_label = f"{len(cats)} categories"

    payload = {
        "objective": obj_label,
        "scope": {
            "label": scope_label,
            "items": int(items.shape[0]),
            "price_areas": int(df["price_area_cd"].nunique()),
            "weeks": int(df["week_start_date"].nunique()),
        },
        "metrics": metrics_payload,
        "promotion_summary": promotion_summary,
        "strategy_contribution": [strategy_rows[bucket] for bucket in strategy_order],
        "item_classes": items[[
            "item_id", "optimizer_bucket", "promo_class", "avg_depth_now", "avg_depth_ly",
            "promo_slots_now", "promo_slots_ly", "ad_slots_now", "ad_slots_ly", "total_slots",
            "promo_slot_share_ty", "ad_share_of_promo_ty",
        ]].to_dict(orient="records"),
        "assortment": summarize_assortment(assortment),
        "ly_actual_context": metrics_payload["sales"].get("ly_actual_context"),
        "diagnostics": diagnostics,
    }
    if payload["assortment"]:
        fy_sales_total = metrics_payload["sales"]["fy_forecast"]
        new_sales = payload["assortment"]["new_items"]["sales"]
        payload["assortment"]["new_share_of_forecast"] = (
            (new_sales / fy_sales_total) if fy_sales_total else None
        )
    payload["promotion_coverage_note"] = promotion_coverage_note(payload)
    return _to_native(payload)


def format_amount(value: float | None, metric: str) -> str:
    """Compact display formatting: dollars for sales/agp, counts for units."""
    if value is None:
        return "n/a"
    sign = "-" if value < 0 else ""
    mag = abs(float(value))
    if mag >= 1_000_000:
        body = f"{mag / 1_000_000:.3f}M"
    elif mag >= 1_000:
        body = f"{mag / 1_000:.1f}K"
    else:
        body = f"{mag:.0f}"
    return f"{sign}${body}" if metric in ("sales", "agp") else f"{sign}{body}"


def executive_summary(payload: dict, metric: str = "sales") -> str:
    """Board-level paragraph: what the year does without the optimizer, what the plan identifies,
    what survives reconciliation as net incremental, and where that lands in total."""
    m = payload.get("metrics", {}).get(metric)
    if not m or not m.get("executive"):
        return "No selected-plan rows were found for the requested scope."
    ex = m["executive"]
    scope = (payload.get("scope") or {}).get("label") or "this scope"

    def _pct(value: float | None) -> str:
        return "n/a" if value is None else f"{abs(value) * 100:.1f}%"

    def _pp(value: float | None) -> str:
        return "n/a" if value is None else f"{value * 100:.1f} percentage points"

    base_dir = "increase" if ex["without_optimizer"] >= 0 else "decline"
    net_dir = "uplift" if ex["net_incremental"] >= 0 else "reduction"
    total_dir = "increase" if ex["total_change"] >= 0 else "decline"
    recon = ex["reconciliation"]
    recon_word = "reductions" if recon < 0 else "additions"
    return (
        f"For {scope}, without the optimizer {metric} were expected to {base_dir} by "
        f"{format_amount(abs(ex['without_optimizer']), metric)}, or approximately "
        f"{_pct(ex['without_optimizer_pct'])}, based on underlying demand and the frozen price "
        f"and cost position. The optimizer identifies "
        f"{format_amount(ex['optimizer_gross'], metric)} of "
        f"gross incremental opportunity. After forecast reconciliation and residual {recon_word} "
        f"of {format_amount(recon, metric)}, the plan delivers a net incremental {net_dir} of "
        f"approximately {format_amount(abs(ex['net_incremental']), metric)}, equivalent to "
        f"{_pp(ex['net_incremental_pct_points'])} of growth. Combined with the underlying "
        f"movement, this results in a final projected {metric} {total_dir} of "
        f"{format_amount(abs(ex['total_change']), metric)}, or {_pct(ex['total_change_pct'])}."
    )


def merchant_statement(payload: dict, metric: str = "sales") -> str:
    """One-paragraph merchant-ready narrative for one metric of a computed payload."""
    m = payload.get("metrics", {}).get(metric)
    if not m:
        return "No selected-plan rows were found for the requested scope."
    summary = payload.get("promotion_summary", {})
    steps = {s["key"]: s["value"] for s in m.get("steps", [])}
    change = m["fy_forecast"] - m["ly_actual"]
    pct = f"{(change / m['ly_actual']) * 100:.1f}%" if m["ly_actual"] else "n/a"
    depth_ly = summary.get("avg_item_depth_ly")
    depth_fy = summary.get("avg_item_depth_fy")
    depth_txt = ""
    if depth_ly is not None and depth_fy is not None:
        depth_txt = (f" while average item-level depth moves from {depth_ly * 100:.1f}% "
                     f"to {depth_fy * 100:.1f}%")
    return (
        f"{metric.upper()} is forecast to move from {format_amount(m['ly_actual'], metric)} to "
        f"{format_amount(m['fy_forecast'], metric)} ({format_amount(change, metric)}, {pct}). "
        f"Promotion coverage changes from {summary.get('items_promoted_ly')} to "
        f"{summary.get('items_promoted_fy')} of {summary.get('total_items')} items{depth_txt}. "
        f"The optimizer contributes {format_amount(m.get('optimizer_total'), metric)}: "
        f"{format_amount(steps.get('optimizer_promoted_no_ad'), metric)} from "
        f"{summary.get('promoted_no_ad_items')} items promoted without advertising, "
        f"{format_amount(steps.get('optimizer_promoted_with_ad'), metric)} from "
        f"{summary.get('promoted_with_ad_items')} items promoted with advertising, and "
        f"{format_amount(steps.get('optimizer_nonpromoted'), metric)} from "
        f"{summary.get('nonpromoted_items')} items with no TY promotional slots, including both "
        "the LY-adjusted promotion-removal estimate and matched non-promo forecast variance. "
        f"Underlying category trend adds {format_amount(steps.get('category_trend'), metric)}, "
        f"post-freeze trend momentum adds {format_amount(steps.get('trend_momentum'), metric)}, "
        f"the regular-price change already realized before the freeze contributes "
        f"{format_amount(steps.get('mechanical_price'), metric)}, "
        f"holding prices frozen past the freeze week contributes "
        f"{format_amount(steps.get('frozen_price_gap', 0.0), metric)}, and "
        f"{format_amount(steps.get('residual'), metric)} remains unexplained residual."
    )


# ---------------------------------------------------------------------------
# Merchant-facing glossary — hover text for every number the UI shows.
# Keyed by the exact field name the UI already binds to, so a tooltip is a dict lookup.
# ---------------------------------------------------------------------------
GLOSSARY: dict[str, dict[str, str]] = {
    # --- waterfall bars -----------------------------------------------------
    "ly_actual": {
        "group": "bar", "title": "Last year actual",
        "tooltip": "What this category actually did in the same weeks last year, matched "
                   "store for store and item for item. Everything to the right explains how "
                   "we get from here to the plan.",
    },
    "category_trend": {
        "group": "bar", "title": "Underlying category trend",
        "tooltip": "Aggregate year-over-year growth across all category items and promotion "
                   "states, measured separately for sales, units, and AGP after last year's "
                   "comparable Q4 endpoint through the freeze week. Each metric's growth is "
                   "applied once to its corresponding Q4 last-year base.",
    },
    "trend_momentum": {
        "group": "bar", "title": "Trend momentum",
        "tooltip": "Acceleration or deceleration implied by the run-rate reached at the "
                   "freeze week. Each last-year Q4 week is scaled by current freeze-week "
                   "performance versus its corresponding last-year week, preserving the "
                   "actual Q4 seasonal shape without compounding weekly growth. This bar is "
                   "the resulting Q4 projection minus the last-year Q4 base after category "
                   "trend, so category trend is not counted twice.",
    },
    "store_footprint": {
        "group": "bar", "title": "Store-count impact",
        "tooltip": "Sales, units, or margin added or lost because the item is forecast in a "
                   "different number of active stores than last year. It holds last year's "
                   "performance per store constant so only the footprint change is measured.",
    },
    "mechanical_price": {
        "group": "bar", "title": "Realized price change",
        "tooltip": "Shelf-price changes that have already happened between last year and the "
                   "date the forecast's prices were locked. Counts both the extra money per "
                   "unit and the volume those price moves win or lose.",
    },
    "frozen_price_gap": {
        "group": "bar", "title": "Frozen-price impact",
        "tooltip": "The forecast holds shelf prices flat from the lock date onward, while the "
                    "BAU comparison lets prices continue moving at the estimated historical "
                    "drift. This bar is the frozen-price outcome minus BAU, including the demand "
                    "response. A positive value means frozen prices perform better; a negative "
                    "value is opportunity available under BAU.",
    },
    "frozen_cost": {
        "group": "bar", "title": "Realized cost change",
        "tooltip": "Cost changes already in place between last year and the lock date. Cost "
                   "never changes what the shopper pays, so it moves margin only — which is "
                   "why this appears on AGP and not on sales or units.",
    },
    "frozen_cost_gap": {
        "group": "bar", "title": "Frozen-cost impact",
        "tooltip": "Costs are held flat from the lock date onward, while the BAU comparison "
                    "lets costs continue moving at the estimated historical drift. This bar is "
                    "frozen-cost AGP minus BAU AGP. A positive value means freezing avoids "
                    "expected cost-driven margin loss; a negative value means BAU costs would "
                    "produce more margin.",
    },
    "optimizer_promoted_no_ad": {
        "group": "bar", "title": "Promoted but no ad",
        "tooltip": "Items with at least one TY promotional slot and no advertised promotional "
                   "slots. The details split "
                   "them into new, deeper, shallower, and unchanged promotion versus LY.",
    },
    "optimizer_promoted_with_ad": {
        "group": "bar", "title": "Promoted with ad",
        "tooltip": "Items with at least one promoted-and-advertised TY slot. The details split them "
                   "into new, deeper, shallower, and unchanged promotion versus LY.",
    },
    "optimizer_nonpromoted": {
        "group": "bar", "title": "Non-promoted",
        "tooltip": "Items with no TY promotional slots. The contribution combines the adjusted "
                   "promotion-removal estimate for items promoted in LY with forecast variance "
                   "for items non-promoted in both periods.",
    },
    "residual": {
        "group": "bar", "title": "Unexplained residual",
        "tooltip": "The part of the change we cannot attribute to demand, price, cost, or the "
                   "promotion plan. Small is good. A large residual means the explanation is "
                   "incomplete and the forecast should not be presented as settled.",
    },
    "fy_forecast": {
        "group": "bar", "title": "Plan forecast",
        "tooltip": "The plan's forecast for these weeks. Every bar to the left explains how "
                   "we got here from last year.",
    },
    # --- four contributors --------------------------------------------------
    "organic_demand": {
        "group": "contributor", "title": "Organic demand",
        "tooltip": "Shopper demand movement in the category — nothing to do with pricing "
                   "decisions or the promotion plan.",
    },
    "pricing_and_cost": {
        "group": "contributor", "title": "Price & cost position",
        "tooltip": "The effect of price and cost — both the changes already made, and the "
                   "decision to hold prices and costs fixed for the planning period.",
    },
    "optimization": {
        "group": "contributor", "title": "Optimization",
        "tooltip": "What the promotion plan adds compared with running no promotions at all.",
    },
    "model_variance": {
        "group": "contributor", "title": "Model variance",
        "tooltip": "Forecast behaviour we cannot attribute to demand, price, or the plan — "
                   "non-promoted variance plus the unexplained residual.",
    },
    # --- executive summary --------------------------------------------------
    "without_optimizer": {
        "group": "executive", "title": "Before the plan",
        "tooltip": "Where the year lands before any promotion activity — demand movement plus "
                   "the price and cost position.",
    },
    "optimizer_gross": {
        "group": "executive", "title": "Gross opportunity",
        "tooltip": "The total the promotion plan identifies, before any forecast "
                   "reconciliation is applied.",
    },
    "reconciliation": {
        "group": "executive", "title": "Reconciliation",
        "tooltip": "Model variance and unexplained residual, charged against the plan so the "
                   "net number stays conservative.",
    },
    "net_incremental": {
        "group": "executive", "title": "Net incremental",
        "tooltip": "What the plan is expected to actually deliver after that conservatism — "
                   "the number to commit to.",
    },
    # --- metric headline ----------------------------------------------------
    "fy_forecast_metric": {
        "group": "metric", "title": "Plan forecast",
        "tooltip": "Forecast total for the selected weeks under the plan.",
    },
    "change_pct": {
        "group": "metric", "title": "Change vs last year",
        "tooltip": "Percentage movement against the same weeks last year.",
    },
    "optimizer_total": {
        "group": "metric", "title": "Optimizer contribution",
        "tooltip": "Everything the promotion plan contributes — the shaded band on the chart.",
    },
    # --- promotion summary --------------------------------------------------
    "items_promoted_fy": {
        "group": "promotion", "title": "Items promoted",
        "tooltip": "How many items the plan promotes at least once, versus how many were "
                   "promoted last year.",
    },
    "avg_item_depth_fy": {
        "group": "promotion", "title": "Average depth (per item)",
        "tooltip": "Average discount across promoted items, each item counted once. This is "
                   "the fair way to say 'we're promoting deeper or shallower than last year'.",
    },
    "avg_slot_depth_fy": {
        "group": "promotion", "title": "Average depth (per promotion)",
        "tooltip": "Average discount across every individual promotion event. Runs higher "
                   "than the per-item figure when the plan promotes deep items more often — "
                   "which is why the per-item number is the honest headline.",
    },
    "promo_slots_fy": {
        "group": "promotion", "title": "Promotion events",
        "tooltip": "Total item / price-area / week combinations carrying a promotion.",
    },
    # --- diagnostics --------------------------------------------------------
    "price_elasticity": {
        "group": "diagnostic", "title": "Price sensitivity",
        "tooltip": "How shoppers here respond to price, measured from this category's own "
                   "history. −1.2 means a 1% price rise loses roughly 1.2% of units.",
    },
    "price_drift": {
        "group": "diagnostic", "title": "Price & cost drift",
        "tooltip": "How fast shelf prices and costs have been moving per year in this "
                   "category, from recent history. Used to work out what freezing them "
                   "hides. You can override it if you know better.",
    },
    "freeze_week": {
        "group": "diagnostic", "title": "Price lock date",
        "tooltip": "The last week of real sales data. Prices and costs in the forecast are "
                   "held at this week's level from here on.",
    },
    "trend_units_ratio": {
        "group": "diagnostic", "title": "Demand trend",
        "tooltip": "Frozen-period year-on-year multiplier for units across all category items "
                   "and promotion states. Sales and AGP use their own corresponding multipliers.",
    },
    "new_items": {
        "group": "assortment", "title": "Newly listed items",
        "tooltip": "Items the plan carries that had no sales in the comparable weeks last year. "
                   "Their forecast is real volume, but there is no last-year figure to compare "
                   "it against, so it arrives as growth by definition.",
    },
    "discontinued_items": {
        "group": "assortment", "title": "Discontinued items",
        "tooltip": "Items that sold last year but are not in this plan at all. They have no "
                   "forecast, so their last-year sales sit OUTSIDE this bridge — which is why "
                   "the starting figure here can be lower than the full category did last year.",
    },
    "ly_not_in_plan": {
        "group": "assortment", "title": "Last year outside the bridge",
        "tooltip": "Last-year sales belonging to discontinued items. Add this to the bridge's "
                   "starting figure to reconcile with the full category's last-year total.",
    },
    "new_share_of_forecast": {
        "group": "assortment", "title": "Share from new items",
        "tooltip": "How much of the plan's forecast comes from items with no last-year history. "
                   "A high share means the growth story depends on unproven items.",
    },
    "freeze_check": {
        "group": "diagnostic", "title": "Is price really frozen?",
        "tooltip": "Checked against the data rather than assumed: if the forecast truly holds "
                   "price and cost flat, every item carries a single price across all future "
                   "weeks. 'Fully frozen' means it does. Anything less means some items carry "
                   "planned changes, and the frozen-price figure understates what is really "
                   "going on.",
    },
    "promo_slots_missing_baseline": {
        "group": "diagnostic", "title": "Events without a comparison",
        "tooltip": "Promotion events with no 'what if we didn't promote' comparison "
                   "available. These land in the reconciliation bar; a high count weakens the "
                   "optimizer attribution.",
    },
}


def glossary_for(key: str) -> dict[str, str] | None:
    """Merchant-facing hover text for one payload field, or None when undocumented."""
    return GLOSSARY.get(key)


def waterfall_steps_frame(payload: dict, metric: str) -> pd.DataFrame:
    """Flatten one metric's steps into a display DataFrame (label / value / running)."""
    steps = (payload.get("metrics", {}).get(metric, {}) or {}).get("steps", [])
    return pd.DataFrame(steps, columns=["key", "label", "display_label", "value", "running"])


# ---------------------------------------------------------------------------
# End-to-end orchestration shared by the notebook (spark.sql) and the API
# ---------------------------------------------------------------------------

def _table_columns_via(query_fn, table: str) -> set[str] | None:
    """Column names (lowercase) via a zero-row probe; None when the probe fails."""
    try:
        probe = query_fn(f"SELECT * FROM {table} LIMIT 0")
        return {str(c).lower() for c in probe.columns}
    except Exception:
        return None


def run_waterfall(
    query_fn,
    *,
    candidate_detail_table: str,
    crf_feature_table: str | None = None,
    store_detail_table: str | None = None,
    run_id: str,
    objective: str = "sales",
    plan_rank: int = 1,
    division_id: str | None = None,
    category: str | None = None,
    category_id: str | None = None,
    item_id: str | None = None,
    price_area_cd: str | None = None,
    week_start: str | None = None,
    week_end: str | None = None,
    trend_weeks: int = 13,
    price_drift_override: float | None = None,
    cost_drift_override: float | None = None,
    freeze_week_override: str | None = None,
    store_item_col: str = "item_id",
    store_price_area_col: str = "price_area_cd",
    store_id_col: str = "facility_integration_id",
    store_week_col: str = "week_start_dt",
    store_active_col: str = "units",
) -> dict:
    """Run the scope queries through ``query_fn`` (sql -> pandas DataFrame with lowercase
    columns) and return the full bridge payload. Optional source columns and the CRF-based bars
    degrade gracefully: failures are reported in ``warnings`` and the unexplained amount lands
    in the residual. ``price_drift_override`` / ``cost_drift_override`` (annual rates, e.g. 0.08
    for +8%/yr) let a merchant replace the estimated drift for commodity-driven categories;
    ``freeze_week_override`` (YYYY-MM-DD) replaces the derived freeze week."""
    objective_label = normalize_objective(objective)
    warnings: list[str] = []

    detail_cols = _table_columns_via(query_fn, candidate_detail_table)
    has_category_id = True if detail_cols is None else "category_id" in detail_cols
    has_division_id = True if detail_cols is None else "division_id" in detail_cols

    selected = query_fn(build_selected_plan_sql(
        candidate_detail_table,
        run_id=run_id, objective=objective, plan_rank=plan_rank,
        category=category, category_id=category_id, division_id=division_id,
        item_id=item_id, price_area_cd=price_area_cd,
        week_start=week_start, week_end=week_end,
        has_category_id=has_category_id, has_division_id=has_division_id,
    ))

    baseline = None
    price = None
    trend_row = None
    momentum_row = None
    drift_row = None
    elasticity_row = None
    freeze_row = None
    assortment = None
    excluded_ly_context = None
    store_effects = None
    ly_circular = None
    week_start_eff = week_start
    week_end_eff = week_end
    if not selected.empty:
        week_start_eff = week_start or str(selected["week_start_date"].min())[:10]
        week_end_eff = week_end or str(selected["week_start_date"].max())[:10]
        baseline = query_fn(build_baseline_sql(
            candidate_detail_table,
            run_id=run_id,
            category=category, category_id=category_id, division_id=division_id,
            item_id=item_id, price_area_cd=price_area_cd,
            week_start=week_start_eff, week_end=week_end_eff,
            has_category_id=has_category_id, has_division_id=has_division_id,
        ))
        # Disabled for performance: this category-level query scans OOS hierarchy items and the
        # consolidated NCRC = '-1' population only to create the context cap above LY actual. It
        # never enters the additive waterfall, so skipping it does not change any bridge value.
        #
        # if not category or not division_id:
        #     warnings.append(
        #         "excluded-LY context skipped: category and division_id are required"
        #     )
        # else:
        #     try:
        #         excluded_ly_context = query_fn(build_excluded_ly_context_sql(
        #             candidate_detail_table,
        #             run_id=run_id, objective=objective, plan_rank=plan_rank,
        #             category=category, division_id=division_id,
        #             detail_has_category_id=has_category_id,
        #             detail_has_division_id=has_division_id,
        #         ))
        #     except Exception as exc:
        #         warnings.append(f"excluded-LY context query failed: {exc}")
        if store_detail_table:
            store_cols = _table_columns_via(query_fn, store_detail_table)
            store_has_category_id = True if store_cols is None else "category_id" in store_cols
            store_has_future_data_flag = (
                store_cols is not None and "future_data_flag" in store_cols
            )
            try:
                store_effects = query_fn(build_store_count_effect_sql(
                    store_detail_table, candidate_detail_table,
                    run_id=run_id, objective=objective, plan_rank=plan_rank,
                    division_id=division_id, category=category, category_id=category_id,
                    item_id=item_id, price_area_cd=price_area_cd,
                    week_start=week_start_eff, week_end=week_end_eff,
                    has_category_id=has_category_id, has_division_id=has_division_id,
                    store_has_category_id=store_has_category_id,
                    store_has_future_data_flag=store_has_future_data_flag,
                    store_item_col=store_item_col,
                    store_price_area_col=store_price_area_col,
                    store_id_col=store_id_col, store_week_col=store_week_col,
                    store_active_col=store_active_col,
                ))
            except Exception as exc:
                warnings.append(f"store-footprint query failed: {exc}")
        if crf_feature_table:
            crf_cols = _table_columns_via(query_fn, crf_feature_table)
            crf_has_category_id = True if crf_cols is None else "category_id" in crf_cols
            # Resolve the digital-depth column ONCE from the table itself and use the same name in
            # every query that reads it. Previously the LY-circular query hardcoded one spelling
            # while the elasticity query and this capability gate assumed the other, so on a table
            # carrying only one of them a query failed or elasticity was skipped with no visible
            # sign beyond a buried warning.
            digital_depth_col = resolve_digital_depth_col(crf_cols)
            crf_has_depths = crf_cols is None or (
                digital_depth_col is not None
                and {c.lower() for c in STORE_DEPTH_COLS} <= crf_cols
            )
            digital_depth_col = digital_depth_col or DEFAULT_DIGITAL_DEPTH_COL
            try:
                ly_circular = query_fn(build_ly_circular_sql(
                    crf_feature_table, candidate_detail_table,
                    run_id=run_id, week_start=week_start, week_end=week_end,
                    objective=objective, plan_rank=plan_rank,
                    division_id=division_id,
                    category=category, category_id=category_id,
                    item_id=item_id, price_area_cd=price_area_cd,
                    has_category_id=crf_has_category_id,
                    detail_has_category_id=has_category_id,
                    detail_has_division_id=has_division_id,
                    digital_depth_col=digital_depth_col,
                ))
            except Exception as exc:
                warnings.append(f"LY circular query failed: {exc}")
            try:
                price = query_fn(build_price_match_sql(
                    crf_feature_table,
                    run_id=run_id, week_start=week_start_eff, week_end=week_end_eff,
                    category=category, category_id=category_id,
                    item_id=item_id, price_area_cd=price_area_cd,
                    has_category_id=crf_has_category_id,
                ))
            except Exception as exc:
                warnings.append(f"price/cost counterfactual query failed: {exc}")
            try:
                assortment = query_fn(build_assortment_sql(
                    crf_feature_table, candidate_detail_table,
                    run_id=run_id, objective=objective,
                    week_start=week_start_eff, week_end=week_end_eff, plan_rank=plan_rank,
                    category=category, category_id=category_id, division_id=division_id,
                    price_area_cd=price_area_cd,
                    crf_has_category_id=crf_has_category_id,
                    detail_has_category_id=has_category_id,
                    detail_has_division_id=has_division_id,
                ))
            except Exception as exc:
                warnings.append(f"assortment query failed: {exc}")
            try:
                freeze_pdf = query_fn(build_freeze_check_sql(
                    crf_feature_table,
                    run_id=run_id,
                    category=category, category_id=category_id,
                    price_area_cd=price_area_cd,
                    has_category_id=crf_has_category_id,
                ))
                if not freeze_pdf.empty:
                    freeze_row = {str(k).lower(): v for k, v in freeze_pdf.iloc[0].to_dict().items()}
            except Exception as exc:
                warnings.append(f"freeze-check query failed: {exc}")
            try:
                drift_pdf = query_fn(build_price_drift_sql(
                    crf_feature_table,
                    run_id=run_id, drift_weeks=trend_weeks,
                    category=category, category_id=category_id,
                    price_area_cd=price_area_cd,
                    has_category_id=crf_has_category_id,
                ))
                if not drift_pdf.empty:
                    drift_row = {str(k).lower(): v for k, v in drift_pdf.iloc[0].to_dict().items()}
            except Exception as exc:
                warnings.append(f"price-drift query failed: {exc}")
            if crf_has_depths:
                try:
                    elasticity_pdf = query_fn(build_price_elasticity_sql(
                        crf_feature_table,
                        run_id=run_id,
                        category=category, category_id=category_id,
                        price_area_cd=price_area_cd,
                        has_category_id=crf_has_category_id,
                        digital_depth_col=digital_depth_col,
                    ))
                    if not elasticity_pdf.empty:
                        elasticity_row = {
                            str(k).lower(): v for k, v in elasticity_pdf.iloc[0].to_dict().items()
                        }
                except Exception as exc:
                    warnings.append(f"price-elasticity query failed: {exc}")
            else:
                warnings.append("CRF table has no promo depth columns; price elasticity skipped")

            # Trend uses all actual items and promotion states and therefore does not depend on
            # the CRF promo-depth fields required by elasticity.
            try:
                trend_pdf = query_fn(build_trend_sql(
                    crf_feature_table, candidate_detail_table,
                    run_id=run_id, objective=objective, plan_rank=plan_rank,
                    week_start=week_start_eff, week_end=week_end_eff,
                    category=category, category_id=category_id, division_id=division_id,
                    price_area_cd=price_area_cd,
                    crf_has_category_id=crf_has_category_id,
                    detail_has_category_id=has_category_id,
                    detail_has_division_id=has_division_id,
                ))
                if not trend_pdf.empty:
                    trend_row = {
                        str(k).lower(): v for k, v in trend_pdf.iloc[0].to_dict().items()
                    }
            except Exception as exc:
                warnings.append(f"trend query failed: {exc}")
            try:
                momentum_pdf = query_fn(build_trend_momentum_sql(
                    crf_feature_table, candidate_detail_table,
                    run_id=run_id, objective=objective, plan_rank=plan_rank,
                    week_start=week_start_eff, week_end=week_end_eff,
                    category=category, category_id=category_id, division_id=division_id,
                    price_area_cd=price_area_cd,
                    crf_has_category_id=crf_has_category_id,
                    detail_has_category_id=has_category_id,
                    detail_has_division_id=has_division_id,
                ))
                if not momentum_pdf.empty:
                    momentum_row = stl_momentum_from_weekly(
                        momentum_pdf, frozen_weeks=16
                    )
            except Exception as exc:
                warnings.append(f"STL trend-momentum calculation failed: {exc}")

    drift_overrides = {
        "price_drift_annual": price_drift_override,
        "cost_drift_annual": cost_drift_override,
        "freeze_week": freeze_week_override,
    }
    payload = compute_waterfall(selected, baseline, price, trend_row, drift_row, elasticity_row,
                                momentum_row=momentum_row, objective=objective,
                                drift_overrides=drift_overrides,
                                freeze_row=freeze_row, assortment=assortment,
                                excluded_ly_context=excluded_ly_context,
                                store_effects=store_effects, ly_circular=ly_circular)
    payload["request"] = {
        "run_id": run_id, "objective": objective_label, "division_id": division_id,
        "category": category, "category_id": category_id, "item_id": item_id,
        "price_area_cd": price_area_cd, "plan_rank": plan_rank,
        "week_start": week_start_eff, "week_end": week_end_eff,
        "trend_weeks": trend_weeks,
        "price_drift_override": price_drift_override,
        "cost_drift_override": cost_drift_override,
        "freeze_week_override": freeze_week_override,
        "candidate_detail_table": candidate_detail_table,
        "crf_feature_table": crf_feature_table,
        "store_detail_table": store_detail_table,
    }
    if warnings:
        payload["warnings"] = warnings
    headline = "sales" if str(objective).lower() in ("sales", "revenue") else str(objective).lower()
    payload["executive_summary"] = executive_summary(payload, headline)
    payload["merchant_statement"] = merchant_statement(payload, headline)
    payload["assortment_note"] = assortment_note(payload, headline)
    payload["source"] = "live"
    return payload
