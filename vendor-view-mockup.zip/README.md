# Vendor view — national event planner (UX mockup)

A self-contained, interactive HTML mockup of the vendor view for the 52-week promo
planner. Open **`vendor-view-options.mockup.html`** in any modern browser — double
click is enough, there is no build step and no server required.

## What is in the bundle

| File | What it is |
|---|---|
| `vendor-view-options.mockup.html` | The whole mockup — markup, CSS and JS in one file |
| `promo-column-override.fonts.css` | `@font-face` declarations for the UI typeface |
| `interx-400…800.woff2` | The font files those declarations load |

Nothing else is needed. **There are no network calls in this file** — no `fetch`, no
fixtures loaded at run time. All data is generated in-page.

## Read the notes inside the page first

Scroll below the mockup. Three sections carry the reasoning that matters more than
the pixels:

1. **"What the run actually calls"** — the real endpoints and payload fields, read
   off `reforecast/payload.ts` and `reforecast/api.ts`.
2. **"This round → Changed"** — every design decision and *why*, including the ones
   that were tried and reversed.
3. **"This round → Still owed by the API"** — the gaps. Read this before estimating.
   Several parts of this screen cannot be built against today's API.

## The load-bearing gaps (summary — detail is in the page)

- **No region → division → ROG → price-area tree** anywhere in the payload. The scope
  picker and the run panel's price-area list are both invented.
- **Price-area numbers repeat across ROGs.** 180 price areas come from only 44 distinct
  numbers, so identity is `division:ROG:number`. `target_scope_ids_json` takes bare
  numbers — `division_id` disambiguates *between* divisions, nothing disambiguates
  *within* one. This is a correctness bug waiting on the real tree.
- **Allowances have no ROG dimension.** `allowance_overrides_json` is one set of amounts
  per item per call, and the run is one POST per division. A division whose two ROGs were
  given different allowances cannot express that in one call — either the override needs
  a ROG key, or the run splits to one POST per ROG (19 calls instead of 13).
- **`AllowanceTier` has no `flat_allowance` or `redemption`** — only `off_invoice`,
  `scan`, `ship_to_store`. Flat is a live, editable input here and it moves dead net,
  so it is a number the user can set and we cannot send.
- **No tactic field anywhere.** `ReceiptItemRow` has no tactic and `ReforecastPayload`
  has nowhere to send one, so the tactic the optimiser chose cannot be read back and a
  custom tactic cannot be posted.

## Simulated vs real

Real: item names, vendors, weeks, item economics shape, the endpoint and payload field
names, the `store_event_1` / `digital_event_1` flags that drive coverage.

Simulated: the 30-vendor set, the ROG/price-area tree and names, store counts, LY
actuals, per-item cost and allowance values, the tactics, and the run itself (a timer,
not a request).

## Interactions worth trying

- Expand a vendor row, then **click an item cell** to open the run panel.
- **Drag the panel by its header** — it stays where you put it across redraws.
- Click a **ROG name** on the left to open that ROG's cost and allowances as an overlay;
  edits stage until **Apply**.
- Run the forecast, then switch the receipt between **By geography** and **By tactic**.
- Hover any **price-area chip** for its friendly name and full identity path.
- **S / C / B** on each item cell is the deal template running that week: all simple,
  all complex, or both kinds present.
