# Scope picker — developer handoff

Two interactive mockups. **No build step, no server, no dependencies.** Open the `.html`
files directly in a browser (double-click, or drag into Chrome/Edge).

```
scope-picker.html        ← the main one
optimiser-levers.html    ← separate mockup, included for reference
interx-*.woff2           ← Inter font files, must stay next to scope-picker.html
```

Each HTML file is fully self-contained: CSS in a single `<style>` block, JS in a single
`<script>` block at the bottom, mock data at the top of that script. Nothing is minified
or transpiled — read it top to bottom.

---

## 1 · scope-picker.html

Replaces five controls on the MyDesk screen — the ASM dropdown, the "other ASM" list, the
ASM VIEW toggle, the category multi-select and the banner-level division pill — with one
rail of Miller columns.

```
VP · Sales Manager · ASM  ┃  Department · Group · Category  ┃  Region · Division
        (people)         seam1        (products)         seam2      (places)
```

### The two seams — the point of the design

The merchant→item relationship is **reported, never enforced**. You are always allowed to
look at anything; the seam tells you whether what you are looking at is actually the
selected merchant's.

| Seam | Question | Breaks when |
|---|---|---|
| **1 · People → Items** | Does this merchant own this? | You navigate into a department/group they don't own, **or** you tick a category owned by someone else |
| **2 · Items → Places** | Is it actually carried there? | A selected category isn't stocked in a selected region |

Rules that matter:

- **Narrowing never breaks a seam.** Deselecting some of your own categories or divisions
  is a smaller scope, not a broken relationship.
- **An empty scope is not broken** — nothing selected means nothing to contradict.
- **Joined is quiet, detached is loud.** Joined = 30px hairline + grey link glyph.
  Detached = 38px amber column, severed-link glyph, count badge, RE-JOIN label.
  This asymmetry is deliberate.
- **Clicking a broken seam fixes it at that join.** Seam 1 walks back to the merchant's
  book; seam 2 drops the categories not carried where you're looking.
- Seam 1 shows a **number** when something is wrongly selected, and **!** when you have
  merely navigated somewhere else (nothing is wrong yet, you're just standing elsewhere).

### Behaviours that are easy to get wrong when rebuilding

- **Switching merchant must not re-point the item path.** Today's screen silently
  re-syncs the category list to the new ASM, which is exactly why the break is invisible.
  Here the path stays put and the seam comes apart. `gotoBook()` is the *only* thing that
  moves the path, and it is only ever called deliberately (the chain, or "My book").
- **Item columns list everything** — all departments, groups and categories, not just the
  merchant's book. Filtering them would make seam 1 unbreakable by navigation. Rows the
  merchant doesn't own are greyed with the owner's first name.
- **Tri-state checkboxes at every level.** Department and Group select their whole subtree;
  the dash state means partially selected (Dairy shows a dash because Timothy owns 13 of
  its 16 categories).
- **Select-all lives in each column header**, scoped to what that column can reach:
  Department → all categories, Group → the current department, Category → the current
  group, Region → all divisions, Division → the current region.
- **"Clear all" clears every axis**, categories and divisions both.
- The seam grid tracks are `auto`, not fixed, so the widened detached column takes its
  room rather than clipping.

### Where the real data goes

All mock data is at the top of the `<script>`, clearly separated:

| Const | Replace with |
|---|---|
| `PEOPLE` | Org hierarchy — `vps` / `sms` / `asms`. `asms[x].geo` is the divisions that ASM operates in. |
| `DEPTS`, `GROUPS`, `CATS` | Item hierarchy. `CATS[x].owner` is the ASM accountable for that category — **this is the field the whole merchant↔item relationship hangs on.** |
| `REGIONS`, `GEODIV` | The four new Albertsons regions and their divisions, with price-area counts. |
| `NOT_CARRIED` | Category → regions where it isn't stocked. Drives seam 2. In production this is a range/assortment lookup. |

Key functions: `links()` computes both seam states; `render()` draws the whole rail;
`seam()` is the shared seam component; `col()` / `rw()` build columns and rows.

### Open questions for the build

1. **"Division" means two things** — an item division (Fresh, Center Store, GM&HBC) and an
   operating division / banner (Jewel-Osco, Shaw's). Suggest the item side is renamed
   **Super Department**. Not resolved.
2. **Nine columns is wide** (~170px each at 1660px). If the real page is narrower, fold VP
   into a header selector above Sales Manager rather than shrinking every column.
3. **Ownership is a matrix, not a tree.** A category can be one ASM's in Jewel-Osco and
   another's in Nor Cal. This mockup assumes one owner per category
   (`CATS[x].owner`); if that isn't true in the real data, seam 1 needs a
   (category × division) → owner lookup instead.
4. **Should operating outside your geography break seam 2?** Currently no — seam 2 is
   item↔location only, so a division outside the merchant's patch is greyed with a `—`
   but stays joined. One-line change if the answer is yes.
5. **Role-based defaults** are described in the page but not implemented — every role
   currently opens on Timothy Antor.

### Not built

Scope is only committed at category level in the sense that the resulting scope object is
`{ asm, cats[], geoDivs[] }`. Vendor/item depth, ROG and price-area columns, saved scopes,
and the Apply/Cancel wiring are all mockup-only.

---

## 2 · optimiser-levers.html

A separate mockup — two options for showing item-level plan-vs-LY variance next to the
promo levers the optimiser pulled. Included because it shares the visual language.

**Note:** this file loads Inter from Google Fonts, so it needs network access to render in
the intended typeface (it falls back to system sans otherwise). The scope picker does not —
it uses the bundled `interx-*.woff2` files, which is why they must stay in the same folder.

---

## Browser support

Built and checked in Chromium. Uses CSS Grid, flexbox, `:has`-free selectors and plain
ES2015+ — no framework, no polyfills. No IE.
